#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";

function argValue(name, fallback = undefined) {
  const index = process.argv.indexOf(name);
  if (index === -1) return fallback;
  return process.argv[index + 1] ?? fallback;
}

function ensureDir(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function fileExists(filePath) {
  return fs.existsSync(filePath) && fs.statSync(filePath).isFile();
}

function resolveCapabilityRoot(inputRoot) {
  const root = path.resolve(inputRoot || ".");
  if (fileExists(path.join(root, "capability-pack.json"))) return root;
  const nested = path.join(root, "capability-pack");
  if (fileExists(path.join(nested, "capability-pack.json"))) return nested;
  const scriptRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
  if (fileExists(path.join(scriptRoot, "capability-pack.json"))) return scriptRoot;
  return root;
}

function checkPaths(root, paths) {
  return paths.map((relativePath) => {
    const absolutePath = path.join(root, relativePath);
    return {
      path: relativePath,
      exists: fileExists(absolutePath)
    };
  });
}

function statusFor(checks) {
  return checks.every((item) => item.exists) ? "ready" : "partial";
}

function flowStatus(ok, partial = false) {
  if (ok) return "verified";
  return partial ? "required" : "blocked";
}

function buildFlowSummary(report) {
  const configuredOk = report.manifest_has_beai_doctor && report.manifest_has_doctor_trust_module;
  const registeredOk = report.manifest_has_beai_doctor;
  const callableOk = report.required_file_status === "ready";
  const outputVerifiedOk = report.package_status === "ready";
  const evidenceState = {
    configured: flowStatus(configuredOk, true),
    registered: flowStatus(registeredOk, true),
    callable: flowStatus(callableOk, true),
    outputVerified: outputVerifiedOk ? "verified" : "unverified",
    doctor: report.telegram_delivery_contract_status === "ready" ? "verified" : "review",
    release: "review"
  };
  return {
    source: "beai-doctor-package-check",
    status_language: "flow_state_evidence_v0_1",
    evidenceState,
    releaseBoundary: "release_verifier_required",
    userMeaning: outputVerifiedOk
      ? "Doctor package integration is ready as a package-level candidate; release wording still requires Release Verifier."
      : "Doctor package integration is not fully output-verified; keep release wording in review state."
  };
}

function checkTelegramDeliveryContract(root) {
  const configPath = path.join(root, "config/beai-telegram-delivery-contract.json");
  if (!fileExists(configPath)) {
    return {
      status: "partial",
      checks: {
        config_exists: false
      }
    };
  }
  const contract = readJson(configPath);
  const rules = contract.rules || {};
  const issueCodes = Array.isArray(contract.doctor_issue_codes) ? contract.doctor_issue_codes : [];
  const checks = {
    config_exists: true,
    internal_final_answer_is_not_delivery: rules.internal_final_answer_is_not_delivery === true,
    telegram_direct_completion_requires_message_tool: rules.telegram_direct_completion_requires_message_tool === true,
    telegram_direct_completion_requires_message_id: rules.telegram_direct_completion_requires_message_id === true,
    reply_payload_sending_is_candidate_only: rules.reply_payload_sending_is_candidate_only === true,
    message_sent_hook_closes_delivery_with_message_id: rules.message_sent_hook_closes_delivery_with_message_id === true,
    gateway_restart_recovery_requires_visible_closeout: rules.gateway_restart_recovery_requires_visible_closeout === true,
    generated_response_requires_delivery_ledger: rules.generated_response_requires_delivery_ledger === true,
    generated_without_message_id_remains_unverified: rules.generated_without_message_id_remains_unverified === true,
    gateway_restart_recovery_requires_pending_delivery_scan: rules.gateway_restart_recovery_requires_pending_delivery_scan === true,
    recovery_resend_requires_idempotency_key: rules.recovery_resend_requires_idempotency_key === true,
    quick_first_status_before_deep_check: rules.quick_first_status_before_deep_check === true,
    phase_timing_telemetry_required: rules.phase_timing_telemetry_required === true,
    long_running_work_requires_visible_progress: rules.long_running_work_requires_visible_progress === true,
    doctor_detects_missing_contract: issueCodes.includes("beai-visible-delivery-contract-missing"),
    doctor_detects_candidate_not_verified: issueCodes.includes("beai-visible-delivery-candidate-not-verified"),
    doctor_detects_message_sent_unverified: issueCodes.includes("beai-visible-delivery-message-sent-unverified"),
    doctor_detects_generated_response_delivery_unverified: issueCodes.includes("beai-generated-response-delivery-unverified"),
    doctor_detects_restart_pending_delivery_scan_missing: issueCodes.includes("beai-gateway-restart-pending-delivery-scan-missing"),
    doctor_detects_quick_first_status_gap: issueCodes.includes("beai-quick-first-status-missing"),
    doctor_detects_phase_timing_missing: issueCodes.includes("beai-phase-timing-telemetry-missing"),
    doctor_detects_long_running_progress_gap: issueCodes.includes("beai-long-running-visible-progress-missing"),
    telegram_direct_non_install_surfaces_are_observer_only: rules.telegram_direct_non_install_surfaces_are_observer_only === true,
    doctor_detects_telegram_direct_hard_surface_risk: issueCodes.includes("beai-telegram-direct-hard-surface-risk")
  };
  return {
    status: Object.values(checks).every(Boolean) ? "ready" : "partial",
    checks
  };
}

function checkOperationalNotificationContract(root) {
  const configPath = path.join(root, "config/beai-operational-notification-contract.json");
  if (!fileExists(configPath)) {
    return {
      status: "partial",
      checks: {
        config_exists: false
      }
    };
  }
  const contract = readJson(configPath);
  const rules = contract.rules || {};
  const issueCodes = Array.isArray(contract.doctor_issue_codes) ? contract.doctor_issue_codes : [];
  const forbiddenRawMarkers = Array.isArray(contract.forbidden_raw_markers) ? contract.forbidden_raw_markers : [];
  const checks = {
    config_exists: true,
    dry_run_default_notify_false: rules.dry_run_default_notify_false === true,
    watchdog_route_dry_run_default_suppressed: rules.watchdog_route_dry_run_default_suppressed === true,
    internal_review_candidates_are_not_user_tasks: rules.internal_review_candidates_are_not_user_tasks === true,
    internal_candidate_markers_must_not_be_sent_raw: rules.internal_candidate_markers_must_not_be_sent_raw === true,
    user_visible_operational_notice_requires_action_frame: rules.user_visible_operational_notice_requires_action_frame === true,
    user_visible_no_action_notice_must_say_no_user_action: rules.user_visible_no_action_notice_must_say_no_user_action === true,
    cron_candidate_is_not_cron_ready: rules.cron_candidate_is_not_cron_ready === true,
    automation_registration_requires_separate_approval: rules.automation_registration_requires_separate_approval === true,
    forbidden_raw_marker_review_first: forbiddenRawMarkers.includes("[검토 우선 / 비영구 메모]"),
    forbidden_raw_marker_watchdog_dry_run: forbiddenRawMarkers.includes("BEAI watchdog route dry-run"),
    doctor_detects_raw_internal_candidate: issueCodes.includes("beai-operational-notice-raw-internal-candidate"),
    doctor_detects_dry_run_over_notified: issueCodes.includes("beai-operational-notice-dry-run-over-notified"),
    doctor_detects_action_frame_missing: issueCodes.includes("beai-operational-notice-action-frame-missing"),
    doctor_detects_cron_readiness_overclaimed: issueCodes.includes("beai-operational-notice-cron-readiness-overclaimed")
  };
  return {
    status: Object.values(checks).every(Boolean) ? "ready" : "partial",
    checks
  };
}

function checkHumanCompanionQualityContract(root) {
  const configPath = path.join(root, "config/beai-human-companion-quality-contract.json");
  if (!fileExists(configPath)) {
    return {
      status: "partial",
      checks: {
        config_exists: false
      }
    };
  }
  const contract = readJson(configPath);
  const rules = contract.rules || {};
  const requiredRuntimeSymbols = Array.isArray(contract.required_runtime_symbols) ? contract.required_runtime_symbols : [];
  const requiredGateCoverage = Array.isArray(contract.required_gate_coverage) ? contract.required_gate_coverage : [];
  const checks = {
    config_exists: true,
    current_request_is_primary_anchor: rules.current_request_is_primary_anchor === true,
    prior_context_supports_but_must_not_override_current_request: rules.prior_context_supports_but_must_not_override_current_request === true,
    response_must_reduce_cognitive_load: rules.response_must_reduce_cognitive_load === true,
    response_must_preserve_user_agency: rules.response_must_preserve_user_agency === true,
    response_must_return_decision_or_action_handle: rules.response_must_return_decision_or_action_handle === true,
    long_conversation_requires_continuity_boundary: rules.long_conversation_requires_continuity_boundary === true,
    repair_turn_requires_trust_recovery_before_expansion: rules.repair_turn_requires_trust_recovery_before_expansion === true,
    artifact_request_requires_usable_output_before_explanation: rules.artifact_request_requires_usable_output_before_explanation === true,
    uncertainty_must_be_separated_from_verified_state: rules.uncertainty_must_be_separated_from_verified_state === true,
    status_claim_must_not_exceed_evidence: rules.status_claim_must_not_exceed_evidence === true,
    conversation_flow_must_track_intent_state_and_situation: rules.conversation_flow_must_track_intent_state_and_situation === true,
    context_must_move_fluidly_without_mechanical_stuffing: rules.context_must_move_fluidly_without_mechanical_stuffing === true,
    correction_signal_must_update_frame_without_defense: rules.correction_signal_must_update_frame_without_defense === true,
    runtime_symbol_profile: requiredRuntimeSymbols.includes("HumanCompanionQualityProfile"),
    runtime_symbol_builder: requiredRuntimeSymbols.includes("buildHumanCompanionQualityProfile"),
    runtime_symbol_turn_plan: requiredRuntimeSymbols.includes("humanCompanionQuality"),
    runtime_symbol_user_reality_frame: requiredRuntimeSymbols.includes("userRealityFrame"),
    runtime_symbol_burden_reducer: requiredRuntimeSymbols.includes("burdenReducer"),
    runtime_symbol_conversation_asset_ledger: requiredRuntimeSymbols.includes("conversationAssetLedger"),
    runtime_symbol_artifact_scene_model: requiredRuntimeSymbols.includes("artifactSceneModel"),
    runtime_symbol_recovery_frame: requiredRuntimeSymbols.includes("recoveryFrame"),
    runtime_symbol_conversational_flow_core: requiredRuntimeSymbols.includes("conversationalFlowCore"),
    gate_flow_regression: requiredGateCoverage.includes("beai-flow-regression-gate"),
    gate_user_scenario: requiredGateCoverage.includes("beai-user-scenario-audit"),
    gate_doctor_package_check: requiredGateCoverage.includes("beai-doctor-package-check"),
    gate_package_verify: requiredGateCoverage.includes("beai-package-verify")
  };
  return {
    status: Object.values(checks).every(Boolean) ? "ready" : "partial",
    checks
  };
}

function checkFrictionAwareGateContract(root) {
  const configPath = path.join(root, "config/beai-friction-aware-gate-contract.json");
  if (!fileExists(configPath)) {
    return {
      status: "partial",
      checks: {
        config_exists: false
      }
    };
  }
  const contract = readJson(configPath);
  const rules = contract?.rules || {};
  const lanes = contract?.lanes || {};
  const issueCodes = Array.isArray(contract?.doctor_issue_codes) ? contract.doctor_issue_codes : [];
  const checks = {
    config_exists: true,
    default_to_fast_lane_for_drafts_and_thinking: rules.default_to_fast_lane_for_drafts_and_thinking === true,
    quiet_checks_should_not_interrupt_user_flow: rules.quiet_checks_should_not_interrupt_user_flow === true,
    approval_required_only_at_risk_transition: rules.approval_required_only_at_risk_transition === true,
    post_action_verification_prevents_completion_overclaim: rules.post_action_verification_prevents_completion_overclaim === true,
    do_not_automate_high_liability_actions: rules.do_not_automate_high_liability_actions === true,
    lane_fast: Boolean(lanes.fast_lane),
    lane_quiet_check: Boolean(lanes.quiet_check),
    lane_approval_gate: Boolean(lanes.approval_gate),
    lane_post_action_verify: Boolean(lanes.post_action_verify),
    lane_do_not_automate: Boolean(lanes.do_not_automate),
    doctor_detects_fast_lane_overblocked: issueCodes.includes("beai-friction-fast-lane-overblocked"),
    doctor_detects_underblocked_risk_transition: issueCodes.includes("beai-friction-risk-transition-underblocked"),
    doctor_detects_completion_overclaimed: issueCodes.includes("beai-friction-completion-overclaimed")
  };
  return {
    status: Object.values(checks).every(Boolean) ? "ready" : "partial",
    checks
  };
}

function checkControlCenterContract(root) {
  const configPath = path.join(root, "config/beai-control-center-contract.json");
  if (!fileExists(configPath)) {
    return {
      status: "partial",
      checks: {
        config_exists: false
      }
    };
  }
  const contract = readJson(configPath);
  const rules = contract?.rules || {};
  const requiredOutputs = Array.isArray(contract?.required_outputs) ? contract.required_outputs : [];
  const issueCodes = Array.isArray(contract?.doctor_issue_codes) ? contract.doctor_issue_codes : [];
  const checks = {
    config_exists: true,
    control_center_is_read_only_by_default: rules.control_center_is_read_only_by_default === true,
    source_live_package_release_states_must_be_separated: rules.source_live_package_release_states_must_be_separated === true,
    verification_reports_are_evidence_not_completion_by_themselves: rules.verification_reports_are_evidence_not_completion_by_themselves === true,
    workflow_candidates_must_not_be_reported_as_active_automation: rules.workflow_candidates_must_not_be_reported_as_active_automation === true,
    missing_or_stale_ledgers_must_be_visible: rules.missing_or_stale_ledgers_must_be_visible === true,
    next_safe_action_must_preserve_approval_boundaries: rules.next_safe_action_must_preserve_approval_boundaries === true,
    live_runtime_reinstall_requires_separate_approval: rules.live_runtime_reinstall_requires_separate_approval === true,
    release_zip_creation_requires_separate_approval: rules.release_zip_creation_requires_separate_approval === true,
    cron_agent_memory_external_send_mutation_requires_separate_approval: rules.cron_agent_memory_external_send_mutation_requires_separate_approval === true,
    required_tool: contract.required_tool === "tools/beai-control-center.mjs",
    required_doc: contract.required_doc === "docs/BEAI-CONTROL-CENTER-v0.1-ko.md",
    output_package_capability_version: requiredOutputs.includes("package capability version"),
    output_runtime_source_version: requiredOutputs.includes("runtime source version"),
    output_runtime_live_version: requiredOutputs.includes("runtime live version"),
    output_latest_release_archive: requiredOutputs.includes("latest release archive"),
    output_state_ledgers: requiredOutputs.includes("state ledgers"),
    output_verification_reports: requiredOutputs.includes("verification reports"),
    output_approval_boundaries: requiredOutputs.includes("approval boundaries"),
    output_next_safe_action: requiredOutputs.includes("next safe action"),
    doctor_detects_contract_missing: issueCodes.includes("beai-control-center-contract-missing"),
    doctor_detects_tool_missing: issueCodes.includes("beai-control-center-tool-missing"),
    doctor_detects_doc_missing: issueCodes.includes("beai-control-center-doc-missing"),
    doctor_detects_live_overclaim: issueCodes.includes("beai-control-center-overclaims-live-state"),
    doctor_detects_automation_candidate_overclaim: issueCodes.includes("beai-control-center-automation-candidate-overclaimed")
  };
  return {
    status: Object.values(checks).every(Boolean) ? "ready" : "partial",
    checks
  };
}

function checkWorkbenchEssentialSkillsContract(root) {
  const configPath = path.join(root, "config/beai-workbench-essential-skills-contract.json");
  if (!fileExists(configPath)) {
    return {
      status: "partial",
      checks: {
        config_exists: false
      }
    };
  }
  const contract = readJson(configPath);
  const rules = contract?.rules || {};
  const studios = Array.isArray(contract?.studios) ? contract.studios : [];
  const stateLabels = Array.isArray(contract?.state_labels) ? contract.state_labels : [];
  const issueCodes = Array.isArray(contract?.doctor_issue_codes) ? contract.doctor_issue_codes : [];
  const checks = {
    config_exists: true,
    human_centered_delegation: rules.workbench_skills_are_human_centered_delegation === true,
    preserves_user_agency: rules.studio_skills_must_preserve_user_agency === true,
    separates_workbench_states: rules.studio_skills_must_separate_draft_generated_checked_and_approval_states === true,
    artifact_specific_quality_gates: rules.quality_gates_must_be_artifact_specific === true,
    visual_design_includes_aesthetics: rules.visual_design_must_include_aesthetic_quality === true,
    research_claim_fact_inference_split: rules.research_must_separate_claim_fact_inference === true,
    data_statistical_boundaries: rules.data_analysis_must_expose_statistical_boundaries === true,
    patterns_not_agents_or_cron: rules.patterns_are_not_agents_or_cron_by_default === true,
    approval_boundary_rule: rules.external_send_publish_memory_agent_cron_require_separate_approval === true,
    completion_claim_evidence_rule: rules.completion_claims_must_not_exceed_evidence === true,
    required_tool: contract.required_tool === "tools/beai-workbench-skill-audit.mjs",
    studio_count: studios.length === 5,
    visual_studio: studios.some((studio) => studio.id === "beai-visual-design-studio"),
    presentation_studio: studios.some((studio) => studio.id === "beai-presentation-studio"),
    document_studio: studios.some((studio) => studio.id === "beai-document-craft-studio"),
    research_studio: studios.some((studio) => studio.id === "beai-research-evidence-studio"),
    data_studio: studios.some((studio) => studio.id === "beai-data-insight-lab"),
    state_draft: stateLabels.includes("draft"),
    state_artifact_generated: stateLabels.includes("artifact_generated"),
    state_visual_checked: stateLabels.includes("visual_checked"),
    state_evidence_checked: stateLabels.includes("evidence_checked"),
    state_formula_checked: stateLabels.includes("formula_checked"),
    state_client_ready_candidate: stateLabels.includes("client_ready_candidate"),
    state_approval_required: stateLabels.includes("approval_required"),
    doctor_detects_contract_missing: issueCodes.includes("beai-workbench-contract-missing"),
    doctor_detects_skill_missing: issueCodes.includes("beai-workbench-skill-missing"),
    doctor_detects_section_missing: issueCodes.includes("beai-workbench-skill-section-missing"),
    doctor_detects_quality_gate_missing: issueCodes.includes("beai-workbench-quality-gate-missing"),
    doctor_detects_approval_boundary_missing: issueCodes.includes("beai-workbench-approval-boundary-missing"),
    doctor_detects_completion_overclaimed: issueCodes.includes("beai-workbench-completion-overclaimed")
  };
  return {
    status: Object.values(checks).every(Boolean) ? "ready" : "partial",
    checks
  };
}

function checkExternalReachContract(root) {
  const configPath = path.join(root, "config/beai-external-reach-contract.json");
  if (!fileExists(configPath)) {
    return {
      status: "partial",
      checks: {
        config_exists: false
      }
    };
  }
  const contract = readJson(configPath);
  const rules = contract?.rules || {};
  const channels = Array.isArray(contract?.channels) ? contract.channels : [];
  const statuses = Array.isArray(contract?.required_statuses) ? contract.required_statuses : [];
  const registryFields = Array.isArray(contract?.source_registry_fields) ? contract.source_registry_fields : [];
  const issueCodes = Array.isArray(contract?.doctor_issue_codes) ? contract.doctor_issue_codes : [];
  const channelIds = channels.map((channel) => channel.id);
  const checks = {
    config_exists: true,
    read_only_by_default: rules.external_reach_is_read_only_by_default === true,
    public_channels_without_account: rules.public_channels_may_be_checked_without_account === true,
    login_cookie_channels_require_approval: rules.account_cookie_or_login_channels_require_separate_approval === true,
    source_registry_access_method: rules.source_registry_must_record_access_method === true,
    source_registry_fetched_at: rules.source_registry_must_record_fetched_at === true,
    source_registry_freshness: rules.source_registry_must_record_freshness === true,
    source_registry_backend_status: rules.source_registry_must_record_backend_status === true,
    claim_fact_inference_split: rules.research_outputs_must_separate_claim_fact_inference === true,
    fallback_limits_visible: rules.fallback_routing_must_not_hide_source_limits === true,
    completion_claim_boundary: rules.completion_claims_must_not_exceed_connector_evidence === true,
    live_checks_optional_read_only: rules.network_live_checks_are_optional_and_read_only === true,
    no_dependency_or_account_mutation: rules.doctor_must_not_install_dependencies_or_mutate_accounts === true,
    required_tool: contract.required_tool === "tools/beai-external-reach-doctor.mjs",
    required_doc: contract.required_doc === "docs/BEAI-EXTERNAL-REACH-LAYER-v0.1-ko.md",
    channel_public_web: channelIds.includes("public_web"),
    channel_github: channelIds.includes("github"),
    channel_youtube: channelIds.includes("youtube"),
    channel_rss: channelIds.includes("rss"),
    channel_x_twitter: channelIds.includes("x_twitter"),
    channel_reddit: channelIds.includes("reddit"),
    channel_social_meta: channelIds.includes("social_meta"),
    status_available: statuses.includes("available"),
    status_limited: statuses.includes("limited"),
    status_needs_login: statuses.includes("needs_login"),
    status_blocked: statuses.includes("blocked"),
    status_unsafe_without_approval: statuses.includes("unsafe_without_approval"),
    status_not_checked: statuses.includes("not_checked"),
    registry_channel: registryFields.includes("channel"),
    registry_access_method: registryFields.includes("access_method"),
    registry_backend_status: registryFields.includes("backend_status"),
    registry_fetched_at: registryFields.includes("fetched_at"),
    registry_freshness: registryFields.includes("freshness"),
    registry_approval_state: registryFields.includes("approval_state"),
    registry_evidence_strength: registryFields.includes("evidence_strength"),
    registry_limitations: registryFields.includes("limitations"),
    social_channels_approval_gated: channels
      .filter((channel) => ["x_twitter", "reddit", "social_meta"].includes(channel.id))
      .every((channel) => channel.approvalRequired === true),
    doctor_detects_contract_missing: issueCodes.includes("beai-external-reach-contract-missing"),
    doctor_detects_tool_missing: issueCodes.includes("beai-external-reach-tool-missing"),
    doctor_detects_doc_missing: issueCodes.includes("beai-external-reach-doc-missing"),
    doctor_detects_channel_missing: issueCodes.includes("beai-external-reach-channel-missing"),
    doctor_detects_approval_boundary_missing: issueCodes.includes("beai-external-reach-approval-boundary-missing"),
    doctor_detects_social_overclaim: issueCodes.includes("beai-external-reach-social-channel-overclaimed"),
    doctor_detects_live_check_failed: issueCodes.includes("beai-external-reach-live-check-failed")
  };
  return {
    status: Object.values(checks).every(Boolean) ? "ready" : "partial",
    checks
  };
}

function renderMarkdown(report) {
  const lines = [];
  lines.push("# BEAI Doctor Package Check");
  lines.push("");
  lines.push(`Generated at: ${report.generated_at}`);
  lines.push(`Package root: ${report.package_root}`);
  lines.push("");
  lines.push("## Summary");
  lines.push("");
  lines.push(`- manifest_has_beai_doctor: ${report.manifest_has_beai_doctor}`);
  lines.push(`- manifest_has_doctor_trust_module: ${report.manifest_has_doctor_trust_module}`);
  lines.push(`- required_file_status: ${report.required_file_status}`);
  lines.push(`- telegram_delivery_contract_status: ${report.telegram_delivery_contract_status}`);
  lines.push(`- operational_notification_contract_status: ${report.operational_notification_contract_status}`);
  lines.push(`- human_companion_quality_contract_status: ${report.human_companion_quality_contract_status}`);
  lines.push(`- friction_aware_gate_contract_status: ${report.friction_aware_gate_contract_status}`);
  lines.push(`- control_center_contract_status: ${report.control_center_contract_status}`);
  lines.push(`- workbench_essential_skills_contract_status: ${report.workbench_essential_skills_contract_status}`);
  lines.push(`- external_reach_contract_status: ${report.external_reach_contract_status}`);
  lines.push(`- trust_gate_status_count: ${report.trust_gate_status_count}`);
  lines.push(`- ledger_entry_count: ${report.ledger_entry_count}`);
  lines.push(`- package_status: ${report.package_status}`);
  lines.push(`- flow_output_verified: ${report.flow_summary?.evidenceState?.outputVerified || "unknown"}`);
  lines.push(`- flow_release: ${report.flow_summary?.evidenceState?.release || "unknown"}`);
  lines.push("");
  lines.push("## Required Files");
  lines.push("");
  for (const item of report.required_files) {
    lines.push(`- ${item.exists ? "OK" : "MISSING"}: ${item.path}`);
  }
  lines.push("");
  lines.push("## Telegram Delivery Contract");
  lines.push("");
  for (const [key, value] of Object.entries(report.telegram_delivery_contract_checks || {})) {
    lines.push(`- ${value ? "OK" : "MISSING"}: ${key}`);
  }
  lines.push("");
  lines.push("## Operational Notification Contract");
  lines.push("");
  for (const [key, value] of Object.entries(report.operational_notification_contract_checks || {})) {
    lines.push(`- ${value ? "OK" : "MISSING"}: ${key}`);
  }
  lines.push("");
  lines.push("## Human Companion Quality Contract");
  lines.push("");
  for (const [key, value] of Object.entries(report.human_companion_quality_contract_checks || {})) {
    lines.push(`- ${value ? "OK" : "MISSING"}: ${key}`);
  }
  lines.push("");
  lines.push("## Friction-Aware Gate Contract");
  lines.push("");
  for (const [key, value] of Object.entries(report.friction_aware_gate_contract_checks || {})) {
    lines.push(`- ${value ? "OK" : "MISSING"}: ${key}`);
  }
  lines.push("");
  lines.push("## Control Center Contract");
  lines.push("");
  for (const [key, value] of Object.entries(report.control_center_contract_checks || {})) {
    lines.push(`- ${value ? "OK" : "MISSING"}: ${key}`);
  }
  lines.push("");
  lines.push("## Workbench Essential Skills Contract");
  lines.push("");
  for (const [key, value] of Object.entries(report.workbench_essential_skills_contract_checks || {})) {
    lines.push(`- ${value ? "OK" : "MISSING"}: ${key}`);
  }
  lines.push("");
  lines.push("## External Reach Contract");
  lines.push("");
  for (const [key, value] of Object.entries(report.external_reach_contract_checks || {})) {
    lines.push(`- ${value ? "OK" : "MISSING"}: ${key}`);
  }
  lines.push("");
  lines.push("## Not Performed");
  lines.push("");
  lines.push("- no live OpenClaw config change");
  lines.push("- no Gateway restart");
  lines.push("- no cron or hook mutation");
  lines.push("- no durable memory write");
  lines.push("- no external send");
  lines.push("- no public release publishing");
  lines.push("");
  return `${lines.join("\n")}\n`;
}

function main() {
  const root = resolveCapabilityRoot(argValue("--root", "."));
  const jsonOutput = path.resolve(argValue("--json-output", "docs/03-verification/generated/beai-doctor-package-check.json"));
  const markdownOutput = path.resolve(argValue("--markdown-output", "docs/03-verification/generated/beai-doctor-package-check.md"));

  const manifest = readJson(path.join(root, "capability-pack.json"));
  const trustGate = readJson(path.join(root, "config/beai-trust-gate-statuses.json"));
  const ledger = readJson(path.join(root, "state/beai/agent-trust-ledger.json"));

  const requiredFiles = checkPaths(root, [
    "skills/beai-doctor/SKILL.md",
    "tools/beai-doctor.js",
    "tools/install-wake-guard-launchagent.js",
    "docs/BEAI-DOCTOR-PACKAGE-INTEGRATION-v0.1-ko.md",
    "docs/BEAI-TRUST-GATE-v0.1-ko.md",
    "docs/BEAI-AGENT-TRUST-LEDGER-v0.1-ko.md",
    "docs/BEAI-CONNECTOR-ONBOARDING-v0.1-ko.md",
    "docs/BEAI-TELEGRAM-DELIVERY-CONTRACT-v0.1-ko.md",
    "docs/BEAI-OPERATIONAL-NOTIFICATION-CONTRACT-v0.1-ko.md",
    "docs/BEAI-HUMAN-COMPANION-QUALITY-CONTRACT-v0.1-ko.md",
    "docs/BEAI-FRICTION-AWARE-GATE-CONTRACT-v0.1-ko.md",
    "docs/BEAI-KNOWLEDGE-LOOP-AUTO-CAPTURE-NOT-AUTO-APPROVE-v0.1-ko.md",
    "docs/BEAI-KOREAN-NATURAL-AI-WRITING-STANDARD-v1.0-ko.md",
    "skills/beai-korean-natural-writing-skill.md",
    "config/beai-trust-gate-statuses.json",
    "config/beai-connector-onboarding-checklist.json",
    "config/beai-telegram-delivery-contract.json",
    "config/beai-operational-notification-contract.json",
    "config/beai-human-companion-quality-contract.json",
    "config/beai-friction-aware-gate-contract.json",
    "config/beai-control-center-contract.json",
    "state/beai/agent-trust-ledger.json",
    "tools/beai-doctor-package-check.mjs",
    "tools/beai-control-center.mjs",
    "tools/beai-workbench-skill-audit.mjs",
    "tools/beai-operational-notification-gate.mjs",
    "tools/beai-organic-flow-audit.mjs",
    "docs/BEAI-CONTROL-CENTER-v0.1-ko.md",
    "docs/BEAI-PACKAGE-ORGANIC-FLOW-AUDIT-v0.1-ko.md",
    "docs/BEAI-WORKBENCH-ESSENTIAL-SKILLS-RESEARCH-DOSSIER-v0.1-ko.md",
    "docs/BEAI-WORKBENCH-ESSENTIAL-SKILLS-DEVELOPMENT-PLAN-v0.1-ko.md",
    "docs/BEAI-WORKBENCH-ESSENTIAL-SKILLS-CONTRACT-v0.1-ko.md",
    "config/beai-workbench-essential-skills-contract.json",
    "skills/beai-visual-design-studio/SKILL.md",
    "skills/beai-presentation-studio/SKILL.md",
    "skills/beai-document-craft-studio/SKILL.md",
    "skills/beai-research-evidence-studio/SKILL.md",
    "skills/beai-data-insight-lab/SKILL.md",
    "docs/BEAI-EXTERNAL-REACH-LAYER-v0.1-ko.md",
    "config/beai-external-reach-contract.json",
    "tools/beai-external-reach-doctor.mjs"
  ]);

  const manifestHasDoctor = Array.isArray(manifest.skills)
    && manifest.skills.some((skill) => skill.id === "beai-doctor");
  const manifestHasDoctorTrustModule = Array.isArray(manifest.candidateModules)
    && manifest.candidateModules.some((module) => module.id === "beai-doctor-runtime-trust-upgrade");
  const telegramDeliveryContract = checkTelegramDeliveryContract(root);
  const operationalNotificationContract = checkOperationalNotificationContract(root);
  const humanCompanionQualityContract = checkHumanCompanionQualityContract(root);
  const frictionAwareGateContract = checkFrictionAwareGateContract(root);
  const controlCenterContract = checkControlCenterContract(root);
  const workbenchEssentialSkillsContract = checkWorkbenchEssentialSkillsContract(root);
  const externalReachContract = checkExternalReachContract(root);

  const requiredFileStatus = statusFor(requiredFiles);
  const packageStatus = manifestHasDoctor && manifestHasDoctorTrustModule && requiredFileStatus === "ready" && telegramDeliveryContract.status === "ready" && operationalNotificationContract.status === "ready" && humanCompanionQualityContract.status === "ready" && frictionAwareGateContract.status === "ready" && controlCenterContract.status === "ready" && workbenchEssentialSkillsContract.status === "ready" && externalReachContract.status === "ready"
    ? "ready"
    : "partial";

  const report = {
    schema: "beai.doctor_package_check.v0.1",
    generated_at: new Date().toISOString(),
    package_root: root,
    manifest_has_beai_doctor: manifestHasDoctor,
    manifest_has_doctor_trust_module: manifestHasDoctorTrustModule,
    required_file_status: requiredFileStatus,
    telegram_delivery_contract_status: telegramDeliveryContract.status,
    telegram_delivery_contract_checks: telegramDeliveryContract.checks,
    operational_notification_contract_status: operationalNotificationContract.status,
    operational_notification_contract_checks: operationalNotificationContract.checks,
    human_companion_quality_contract_status: humanCompanionQualityContract.status,
    human_companion_quality_contract_checks: humanCompanionQualityContract.checks,
    friction_aware_gate_contract_status: frictionAwareGateContract.status,
    friction_aware_gate_contract_checks: frictionAwareGateContract.checks,
    control_center_contract_status: controlCenterContract.status,
    control_center_contract_checks: controlCenterContract.checks,
    workbench_essential_skills_contract_status: workbenchEssentialSkillsContract.status,
    workbench_essential_skills_contract_checks: workbenchEssentialSkillsContract.checks,
    external_reach_contract_status: externalReachContract.status,
    external_reach_contract_checks: externalReachContract.checks,
    trust_gate_status_count: Array.isArray(trustGate.statuses) ? trustGate.statuses.length : 0,
    ledger_entry_count: Array.isArray(ledger.entries) ? ledger.entries.length : 0,
    package_status: packageStatus,
    required_files: requiredFiles,
    not_performed: [
      "live OpenClaw config change",
      "Gateway restart",
      "cron or hook mutation",
      "durable memory write",
      "external send",
      "public release publishing"
    ]
  };
  report.flow_summary = buildFlowSummary(report);
  report.flow_state_evidence = report.flow_summary.evidenceState;

  ensureDir(jsonOutput);
  fs.writeFileSync(jsonOutput, `${JSON.stringify(report, null, 2)}\n`, "utf8");
  ensureDir(markdownOutput);
  fs.writeFileSync(markdownOutput, renderMarkdown(report), "utf8");

  process.stdout.write(`${JSON.stringify({
    json_output: jsonOutput,
    markdown_output: markdownOutput,
    package_status: packageStatus,
    required_file_status: requiredFileStatus
  }, null, 2)}\n`);
}

main();
