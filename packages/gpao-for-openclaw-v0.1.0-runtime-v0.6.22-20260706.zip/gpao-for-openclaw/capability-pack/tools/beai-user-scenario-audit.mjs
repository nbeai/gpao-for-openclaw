#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";

function parseArgs(argv) {
  const options = {
    root: ".",
    format: "json",
    output: null,
    stdout: false
  };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--root") options.root = argv[++index];
    else if (arg === "--format") options.format = argv[++index];
    else if (arg === "--output") options.output = argv[++index];
    else if (arg === "--stdout") options.stdout = true;
    else if (arg === "--help" || arg === "-h") options.help = true;
  }
  return options;
}

function usage() {
  return `Usage:
  node tools/beai-user-scenario-audit.mjs [--root <repo-root|capability-pack-root>] [--format json|md] [--output <path>] [--stdout]

This helper performs a read-only user-scenario audit for BEAI Package on OpenClaw.
It does not write memory, change OpenClaw config, register cron/hooks/agents, send messages, package releases, or restart Gateway.
`;
}

function isFile(filePath) {
  return fs.existsSync(filePath) && fs.statSync(filePath).isFile();
}

function resolveCapabilityRoot(inputRoot) {
  const root = path.resolve(inputRoot || ".");
  if (isFile(path.join(root, "capability-pack.json"))) return root;
  const nested = path.join(root, "capability-pack");
  if (isFile(path.join(nested, "capability-pack.json"))) return nested;
  const scriptRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
  if (isFile(path.join(scriptRoot, "capability-pack.json"))) return scriptRoot;
  return root;
}

function readText(root, relativePath) {
  const resolved = path.resolve(root, relativePath);
  try {
    return fs.readFileSync(resolved, "utf8");
  } catch {
    return "";
  }
}

function readJson(root, relativePath) {
  const text = readText(root, relativePath);
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function ensureOutputPath(outputPath) {
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
}

function fileContains(files, root, relativePath, pattern) {
  const text = files[relativePath] ?? readText(root, relativePath);
  return pattern.test(text);
}

function fileAbsent(files, root, relativePath, pattern) {
  return !fileContains(files, root, relativePath, pattern);
}

function jsonAt(json, pathExpression) {
  if (!json) return undefined;
  return pathExpression.split(".").reduce((value, key) => {
    if (value === undefined || value === null) return undefined;
    if (key.endsWith("[]")) {
      const arrayKey = key.slice(0, -2);
      return Array.isArray(value[arrayKey]) ? value[arrayKey] : undefined;
    }
    return value[key];
  }, json);
}

function compareRuntimeFiles(packageJson, packageDistJson) {
  const packageFiles = new Set(Array.isArray(packageJson?.files) ? packageJson.files : []);
  const distFiles = new Set(Array.isArray(packageDistJson?.files) ? packageDistJson.files : []);
  const missingFromPackage = [...distFiles].filter((item) => !packageFiles.has(item));
  const extraInPackage = [...packageFiles].filter((item) => !distFiles.has(item));
  return { packageFiles: [...packageFiles], distFiles: [...distFiles], missingFromPackage, extraInPackage };
}

function makeCheck(id, description, passed, evidence, severity = "P2") {
  return { id, description, status: passed ? "pass" : "fail", evidence, severity };
}

function scenarioStatus(checks) {
  if (checks.some((check) => check.status === "fail" && check.severity === "P0")) return "fail";
  if (checks.some((check) => check.status === "fail")) return "partial";
  return "pass";
}

function buildScenario({ id, title, userRisk, checks, recommendation }) {
  const status = scenarioStatus(checks);
  return {
    id,
    title,
    userRisk,
    status,
    checks,
    recommendation
  };
}

function buildReport(root) {
  const files = {};
  const runtimeCore = "../plugin/beai-runtime/src/runtime-core.ts";
  const runtimeIndex = "../plugin/beai-runtime/src/index.ts";
  const runtimeReadme = "../plugin/beai-runtime/README.md";
  const runtimeDistReadme = "../plugin/beai-runtime/README.dist.md";
  const rootReadme = "../README.md";
  const capReadme = "README.md";
  const contract = "config/beai-telegram-delivery-contract.json";
  const operationalNotificationContract = "config/beai-operational-notification-contract.json";
  const operationalNotificationDoc = "docs/BEAI-OPERATIONAL-NOTIFICATION-CONTRACT-v0.1-ko.md";
  const operationalNotificationGate = "tools/beai-operational-notification-gate.mjs";
  const humanCompanionContract = "config/beai-human-companion-quality-contract.json";
  const humanCompanionDoc = "docs/BEAI-HUMAN-COMPANION-QUALITY-CONTRACT-v0.1-ko.md";
  const actionSemanticsContract = "config/beai-action-semantics-contract.json";
  const actionSemanticsDoc = "docs/BEAI-ACTION-SEMANTICS-AND-RECOVERY-CLAIM-CONTRACT-v0.1-ko.md";
  const frictionAwareGateContract = "config/beai-friction-aware-gate-contract.json";
  const frictionAwareGateDoc = "docs/BEAI-FRICTION-AWARE-GATE-CONTRACT-v0.1-ko.md";
  const controlCenterContract = "config/beai-control-center-contract.json";
  const controlCenterDoc = "docs/BEAI-CONTROL-CENTER-v0.1-ko.md";
  const controlCenterTool = "tools/beai-control-center.mjs";
  const workbenchContract = "config/beai-workbench-essential-skills-contract.json";
  const workbenchContractDoc = "docs/BEAI-WORKBENCH-ESSENTIAL-SKILLS-CONTRACT-v0.1-ko.md";
  const workbenchResearchDossier = "docs/BEAI-WORKBENCH-ESSENTIAL-SKILLS-RESEARCH-DOSSIER-v0.1-ko.md";
  const workbenchDevelopmentPlan = "docs/BEAI-WORKBENCH-ESSENTIAL-SKILLS-DEVELOPMENT-PLAN-v0.1-ko.md";
  const workbenchAuditTool = "tools/beai-workbench-skill-audit.mjs";
  const externalReachContract = "config/beai-external-reach-contract.json";
  const externalReachDoc = "docs/BEAI-EXTERNAL-REACH-LAYER-v0.1-ko.md";
  const externalReachDoctor = "tools/beai-external-reach-doctor.mjs";
  const visualDesignSkill = "skills/beai-visual-design-studio/SKILL.md";
  const presentationSkill = "skills/beai-presentation-studio/SKILL.md";
  const documentCraftSkill = "skills/beai-document-craft-studio/SKILL.md";
  const researchEvidenceSkill = "skills/beai-research-evidence-studio/SKILL.md";
  const dataInsightSkill = "skills/beai-data-insight-lab/SKILL.md";
  const contractDoc = "docs/BEAI-TELEGRAM-DELIVERY-CONTRACT-v0.1-ko.md";
  const doctor = "tools/beai-doctor.js";
  const flowGate = "tools/beai-flow-regression-gate.mjs";
  const knowledgeLoopDoc = "docs/BEAI-KNOWLEDGE-LOOP-AUTO-CAPTURE-NOT-AUTO-APPROVE-v0.1-ko.md";
  const koreanDoc = "docs/BEAI-KOREAN-NATURAL-AI-WRITING-STANDARD-v1.0-ko.md";
  const packageManifest = "capability-pack.json";
  const packageJson = readJson(root, "../plugin/beai-runtime/package.json");
  const packageDistJson = readJson(root, "../plugin/beai-runtime/package.dist.json");
  const manifest = readJson(root, packageManifest);
  const deliveryContract = readJson(root, contract);
  const operationalContract = readJson(root, operationalNotificationContract);
  const humanCompanionQualityContract = readJson(root, humanCompanionContract);
  const actionSemanticsQualityContract = readJson(root, actionSemanticsContract);
  const frictionAwareGateQualityContract = readJson(root, frictionAwareGateContract);
  const controlCenterQualityContract = readJson(root, controlCenterContract);
  const workbenchQualityContract = readJson(root, workbenchContract);
  const externalReachQualityContract = readJson(root, externalReachContract);
  const runtimeFiles = compareRuntimeFiles(packageJson, packageDistJson);

  const rules = deliveryContract?.rules || {};
  const issueCodes = Array.isArray(deliveryContract?.doctor_issue_codes) ? deliveryContract.doctor_issue_codes : [];
  const operationalRules = operationalContract?.rules || {};
  const humanCompanionRules = humanCompanionQualityContract?.rules || {};
  const frictionAwareRules = frictionAwareGateQualityContract?.rules || {};
  const frictionAwareLanes = frictionAwareGateQualityContract?.lanes || {};
  const controlCenterRules = controlCenterQualityContract?.rules || {};
  const controlCenterOutputs = Array.isArray(controlCenterQualityContract?.required_outputs)
    ? controlCenterQualityContract.required_outputs
    : [];
  const workbenchRules = workbenchQualityContract?.rules || {};
  const workbenchStudios = Array.isArray(workbenchQualityContract?.studios) ? workbenchQualityContract.studios : [];
  const externalReachRules = externalReachQualityContract?.rules || {};
  const externalReachChannels = Array.isArray(externalReachQualityContract?.channels) ? externalReachQualityContract.channels : [];
  const externalReachChannelIds = new Set(externalReachChannels.map((channel) => channel.id));
  const humanCompanionRuntimeSymbols = Array.isArray(humanCompanionQualityContract?.required_runtime_symbols)
    ? humanCompanionQualityContract.required_runtime_symbols
    : [];
  const recoveryRequiredEvidence = Array.isArray(actionSemanticsQualityContract?.action_classes?.repair?.required_evidence)
    ? actionSemanticsQualityContract.action_classes.repair.required_evidence
    : [];
  const recoveryForbiddenClaims = Array.isArray(actionSemanticsQualityContract?.recovery_claim_gate?.if_missing_any_required_evidence?.must_not_use)
    ? actionSemanticsQualityContract.recovery_claim_gate.if_missing_any_required_evidence.must_not_use
    : [];
  const correctionTriggers = Array.isArray(actionSemanticsQualityContract?.correction_escalator?.trigger_phrases)
    ? actionSemanticsQualityContract.correction_escalator.trigger_phrases
    : [];
  const forbiddenOperationalMarkers = Array.isArray(operationalContract?.forbidden_raw_markers) ? operationalContract.forbidden_raw_markers : [];
  const skills = Array.isArray(manifest?.skills) ? manifest.skills : [];
  const knowledgeLoopSkill = skills.find((skill) => skill.id === "beai-knowledge-loop");
  const workbenchSkillIds = [
    "beai-visual-design-studio",
    "beai-presentation-studio",
    "beai-document-craft-studio",
    "beai-research-evidence-studio",
    "beai-data-insight-lab"
  ];
  const manifestSkillIds = new Set(skills.map((skill) => skill.id));

  const scenarios = [
    buildScenario({
      id: "S01-install-first-run-expectation",
      title: "첫 설치 사용자가 stable one-command install로 오해하지 않는가",
      userRisk: "사용자가 alpha package를 production-ready installer로 오해하면 설치 실패, rollback 부재, 지원 기대치 mismatch가 생긴다.",
      checks: [
        makeCheck("root-readme-alpha-staging", "Root README keeps alpha/public staging wording.", fileContains(files, root, rootReadme, /alpha public staging/i), "README contains alpha public staging wording.", "P0"),
        makeCheck("root-readme-not-production", "Root README rejects production-ready installer wording.", fileContains(files, root, rootReadme, /not yet be described as a stable one-command installer/i), "README warns against stable one-command installer claims.", "P0"),
        makeCheck("runtime-install-surface-present", "Runtime package declares OpenClaw install surface.", Boolean(packageJson?.openclaw?.install?.clawhubSpec), "package.json has openclaw.install.clawhubSpec.", "P1")
      ],
      recommendation: "Keep alpha wording visible until clean-environment install, rollback, and ClawHub validation are verified."
    }),
    buildScenario({
      id: "S02-telegram-normal-reply-not-replaced",
      title: "Telegram 일반 요청이 BEAI 표면 응답으로 대체되지 않는가",
      userRisk: "사용자는 질문에 대한 답 대신 승인/복구/상태 안내만 받아 대화가 막힌 것처럼 느낄 수 있다.",
      checks: [
        makeCheck("observer-only-runtime-evidence", "Runtime records observer-only deferral for Telegram direct hard surfaces.", fileContains(files, root, runtimeIndex, /telegram direct hard surface deferred to model/), "Runtime contains deferral evidence.", "P0"),
        makeCheck("observer-only-contract", "Delivery contract declares non-install Telegram surfaces observer-only.", rules.telegram_direct_non_install_surfaces_are_observer_only === true, "Contract rule is true.", "P0"),
        makeCheck("flow-gate-covers-observer-only", "Regression gate includes Telegram direct hard surface guard.", fileContains(files, root, flowGate, /telegram_reply_blocked_by_beai_surface/), "Flow gate has regression lane.", "P1")
      ],
      recommendation: "Add runtime-level fixture simulation later; current package has static and contract guards."
    }),
    buildScenario({
      id: "S03-telegram-completion-without-message-id",
      title: "내부 final이나 생성된 답변만으로 Telegram 완료를 주장하지 않는가",
      userRisk: "사용자는 실제로 메시지를 못 받았는데 시스템이 완료라고 말하는 가장 치명적인 신뢰 손상을 겪는다.",
      checks: [
        makeCheck("internal-final-not-delivery", "Contract says internal final_answer is not delivery.", rules.internal_final_answer_is_not_delivery === true, "Contract rule is true.", "P0"),
        makeCheck("message-id-required", "Contract requires messageId for Telegram direct completion.", rules.telegram_direct_completion_requires_message_id === true, "Contract rule is true.", "P0"),
        makeCheck("runtime-ledger-generated-unverified", "Runtime records generated response as unverified until messageId.", fileContains(files, root, runtimeIndex, /Generated response is not Telegram delivery[\s\S]{0,180}message_sent success with messageId/), "Runtime generated-response ledger note is present.", "P0")
      ],
      recommendation: "Keep messageId evidence mandatory; do not downgrade this to a warning."
    }),
    buildScenario({
      id: "S04-repeated-footer-and-stale-handle",
      title: "오래된 확인 문구가 답변 마지막에 반복되지 않는가",
      userRisk: "사용자 지시를 무시하는 것처럼 보이고, 이전 작업의 맥락이 현재 답변을 오염시킨다.",
      checks: [
        makeCheck("footer-sanitizer-present", "Runtime has repeated footer sanitizer.", fileContains(files, root, runtimeCore, /function sanitizeRepeatedFooterInstruction/), "Sanitizer function is present.", "P0"),
        makeCheck("forced-footer-rule-inverted", "Runtime guidance forbids repeated decision-handle footer.", fileContains(files, root, runtimeCore, /final answer should not append the current decision handle as a repeated footer/), "Inverted guard text is present.", "P0"),
        makeCheck("stale-forced-rule-not-rendered-raw", "Old raw forced-footer instruction is not rendered directly.", fileAbsent(files, root, runtimeCore, /"answer should end with the current decision handle"/), "No raw quoted forced-footer rule remains.", "P1")
      ],
      recommendation: "Keep this in scenario audit because it was a real user trust failure, not a cosmetic wording issue."
    }),
    buildScenario({
      id: "S05-current-request-after-session-transition",
      title: "세션 전환 후 오래된 작업이 현재 요청을 덮지 않는가",
      userRisk: "사용자는 방금 말한 요청 대신 이전 핸들, 이전 도메인, 이전 계획이 답변에 붙는 불편을 겪는다.",
      checks: [
        makeCheck("current-input-render-anchor", "Runtime overlay renders currentTurn.cleanInput.", fileContains(files, root, runtimeCore, /current_input:\s*\$\{plan\.currentTurn\.cleanInput\}/), "current_input render anchor exists.", "P0"),
        makeCheck("telegram-transcript-latest-user-fix", "Runtime has Telegram transcript/latest user extraction logic.", fileContains(files, root, runtimeCore, /Park Jongyoon|latest.*user|currentTurn\.cleanInput/i), "Current-input extraction markers are present.", "P1"),
        makeCheck("handoff-seed-sanitized", "Handoff/session seed closure handle is sanitized.", fileContains(files, root, runtimeCore, /sanitize(?:RepeatedFooterInstruction|ContinuityStateText)\(handoffState\?\.closure_handle/), "Handoff seed sanitizer path exists.", "P1")
      ],
      recommendation: "Add fixture tests for numeric Telegram transcript and handoff overlay in the runtime package test suite."
    }),
    buildScenario({
      id: "S06-long-work-visible-progress",
      title: "긴 작업 중 사용자가 침묵으로 느끼지 않도록 progress 기준이 있는가",
      userRisk: "작업은 진행 중이어도 Telegram 사용자는 멈춤, 먹통, 무시로 느낀다.",
      checks: [
        makeCheck("quick-first-status-contract", "Delivery contract requires quick first status.", rules.quick_first_status_before_deep_check === true, "Contract rule is true.", "P1"),
        makeCheck("long-running-progress-contract", "Delivery contract requires visible progress for long-running work.", rules.long_running_work_requires_visible_progress === true, "Contract rule is true.", "P1"),
        makeCheck("doctor-detects-progress-gap", "Doctor issue code detects long-running visible progress gap.", issueCodes.includes("beai-long-running-visible-progress-missing"), "Doctor issue code is present.", "P1")
      ],
      recommendation: "The contract exists; later live verification should prove progress actually reaches the source conversation."
    }),
    buildScenario({
      id: "S07-approval-friction-and-auto-mutation",
      title: "승인 경계가 안전하지만 과도한 마찰이 되지 않는가",
      userRisk: "승인이 필요한 작업과 읽기/점검이 섞이면 사용자는 매번 막히거나 반대로 위험한 자동 실행을 겪는다.",
      checks: [
        makeCheck("safe-but-pleasant-policy", "Manifest keeps safe-but-pleasant policy.", fileContains(files, root, packageManifest, /without creating avoidable friction, delay, repeated questions, or procedural theater/i), "Manifest includes safe-but-pleasant wording.", "P1"),
        makeCheck("cron-default-not-auto", "Root README says package does not create cron jobs automatically.", fileContains(files, root, rootReadme, /create cron jobs automatically/), "Root README excludes automatic cron creation.", "P0"),
        makeCheck("automation-approval-boundary", "Knowledge Loop doc keeps auto-capture separate from approval.", fileContains(files, root, knowledgeLoopDoc, /Auto-capture, not auto-approve\./), "Auto-capture boundary exists.", "P0")
      ],
      recommendation: "Keep read-only checks auto-proceeding, but require explicit approval for cron, Gateway, config, memory, external send, and release actions."
    }),
    buildScenario({
      id: "S08-doctor-help-and-user-control",
      title: "사용자가 Doctor 도움말만 보려다 실제 진단이 실행되지 않는가",
      userRisk: "도움말 확인이 상태 조회나 진단 실행으로 이어지면 도구 신뢰가 낮아진다.",
      checks: [
        makeCheck("doctor-help-implemented", "Doctor handles --help or -h before diagnosis.", fileContains(files, root, doctor, /--help|\b-h\b/) && fileContains(files, root, doctor, /Usage:|사용법|usage/i), "Help handling text should exist.", "P1"),
        makeCheck("doctor-mode-check-visible", "Doctor exposes explicit mode/check language.", fileContains(files, root, doctor, /mode=check|--mode/), "Mode/check language is present.", "P2")
      ],
      recommendation: "If this fails in live CLI, implement --help as usage-only and exit before any OpenClaw probe."
    }),
    buildScenario({
      id: "S09-doctor-freshness-and-stale-log-risk",
      title: "Doctor가 과거 로그를 현재 장애처럼 과장하지 않는가",
      userRisk: "이미 복구된 문제를 현재 장애로 보고하면 사용자가 불필요한 재시작이나 설정 변경을 하게 된다.",
      checks: [
        makeCheck("freshness-language-present", "Doctor contains freshness/window language.", fileContains(files, root, doctor, /freshness|evidence window|historical_signal|not currently reproduced/i), "Freshness language is present if true.", "P1"),
        makeCheck("doctor-evidence-window-configurable", "Doctor has a configurable live evidence freshness window.", fileContains(files, root, doctor, /BEAI_DOCTOR_LIVE_EVIDENCE_WINDOW_MS|liveEvidenceFreshnessWindowMs/), "Live evidence freshness window exists.", "P1"),
        makeCheck("historical-gap-not-current-failure", "Doctor separates historical speed/progress gaps from current failure proof.", fileContains(files, root, doctor, /historicalDetected|historicalLongestGapMs|beai-historical-quick-first-status-gap/), "Historical gap separation exists.", "P1"),
        makeCheck("connected-not-roundtrip-separated", "Doctor separates connected from roundtrip verified.", fileContains(files, root, doctor, /connected-but-not-roundtrip-verified/), "Connected-but-not-roundtrip issue exists.", "P1")
      ],
      recommendation: "Add evidence timestamp/window to every log-derived issue and lower stale findings to review/historical_signal."
    }),
    buildScenario({
      id: "S10-runtime-package-file-truth",
      title: "실제 npm pack 파일 목록이 의도한 dist 패키지와 일치하는가",
      userRisk: "release note, README, dist 파일이 빠지거나 다른 파일이 들어가 설치자가 다른 내용을 받는다.",
      checks: [
        makeCheck("package-json-readable", "Runtime package.json can be parsed.", Boolean(packageJson), "package.json parse result exists.", "P0"),
        makeCheck("package-dist-readable", "Runtime package.dist.json can be parsed.", Boolean(packageDistJson), "package.dist.json parse result exists.", "P0"),
        makeCheck("package-files-match-dist-files", "package.json files match package.dist.json files.", runtimeFiles.missingFromPackage.length === 0 && runtimeFiles.extraInPackage.length === 0, `missingFromPackage=${runtimeFiles.missingFromPackage.join(",") || "none"} extraInPackage=${runtimeFiles.extraInPackage.join(",") || "none"}`, "P0")
      ],
      recommendation: "Align package.json and package.dist.json, then add npm pack dry-run output to the regression gate."
    }),
    buildScenario({
      id: "S11-package-default-vs-local-live-evidence",
      title: "새 사용자에게 기본 설치 기능과 윤의 로컬 적용 증거가 섞여 보이지 않는가",
      userRisk: "패키지를 설치하면 cron, watchdog, persistent lane이 이미 켜지는 것처럼 오해할 수 있다.",
      checks: [
        makeCheck("manifest-no-registered-automations-as-default", "Capability manifest does not list local registeredAutomations as default package state.", !Array.isArray(knowledgeLoopSkill?.registeredAutomations), "registeredAutomations should be moved to local evidence if present.", "P0"),
        makeCheck("cap-readme-local-evidence-separated", "Capability README clearly says local automation evidence is not default install.", fileContains(files, root, capReadme, /local.*evidence.*not.*default|not installed by default/i), "README separates local evidence from default install if true.", "P0")
      ],
      recommendation: "Move local cron UUIDs and force-run evidence into local verification docs, not public/default capability manifest."
    }),
    buildScenario({
      id: "S12-clean-environment-and-clawhub-validation",
      title: "깨끗한 환경에서 설치/검증 경로가 닫혀 있는가",
      userRisk: "개발자 환경에서는 되지만 새 사용자의 OpenClaw에서는 설치, hook, dependency, route가 실패할 수 있다.",
      checks: [
        makeCheck("root-readme-clean-env-needed", "Root README says clean OpenClaw environment checks are still needed.", fileContains(files, root, rootReadme, /clean OpenClaw environment/i), "Clean environment requirement is documented.", "P0"),
        makeCheck("clawhub-validation-not-overclaimed", "Package does not claim ClawHub validation is closed.", fileAbsent(files, root, rootReadme, /ClawHub validation verified|clawhub package validate.*pass/i), "No ClawHub validation pass claim found.", "P0")
      ],
      recommendation: "Do not call public install ready until clean environment install and ClawHub validation are actually run."
    }),
    buildScenario({
      id: "S13-memory-capture-without-auto-approval",
      title: "메모리 후보가 사용자 승인 없이 장기 기억으로 승격되지 않는가",
      userRisk: "사용자 말이나 작업 흔적이 원치 않게 장기 기억 또는 자동화 판단으로 굳어진다.",
      checks: [
        makeCheck("approved-requires-user-approval", "Approved state requires explicit user approval.", fileContains(files, root, knowledgeLoopDoc, /`approved`: 사용자 명시 승인 필요/), "Approved state boundary exists.", "P0"),
        makeCheck("memory-current-judgment-impact", "Knowledge Loop separates current judgment impact.", fileContains(files, root, "tools/beai-knowledge-loop.mjs", /current_judgment_impact/), "current_judgment_impact exists.", "P1")
      ],
      recommendation: "Keep auto-capture review-only and route durable memory to explicit approval."
    }),
    buildScenario({
      id: "S14-korean-status-wording",
      title: "한국어 답변이 상태를 과장하거나 번역투로 불편하게 만들지 않는가",
      userRisk: "검증/적용/전송/배포가 섞이면 사용자는 실제 상태를 잘못 이해한다.",
      checks: [
        makeCheck("korean-status-separation", "Korean standard separates completion and verification evidence.", fileContains(files, root, koreanDoc, /완료.*검증 증거|검증하지 않은 것을.*완료|완료 여부와 검증 범위/), "Korean standard includes completion/evidence separation.", "P1"),
        makeCheck("root-readme-status-separation", "Root README separates ready/partial/unverified/etc.", fileContains(files, root, rootReadme, /ready, partial, unverified, blocked, needs approval, on hold, or unsafe/), "Status vocabulary is present.", "P1")
      ],
      recommendation: "Use the Korean standard for reports and Telegram closeouts, especially after failures."
    }),
    buildScenario({
      id: "S15-tool-log-and-internal-overlay-leak",
      title: "내부 로그/오버레이가 사용자 답변에 새지 않는가",
      userRisk: "사용자는 내부 상태명, 디버그 라벨, 도구 로그를 답변으로 받아 혼란과 불신을 겪는다.",
      checks: [
        makeCheck("internal-process-stripper", "Runtime has internal process line pattern filtering.", fileContains(files, root, runtimeCore, /INTERNAL_PROCESS_LINE_PATTERNS/), "Internal process stripper exists.", "P1"),
        makeCheck("runtime-docs-avoid-overclaim", "README keeps runtime status boundary language.", fileContains(files, root, rootReadme, /claim Telegram completion without messageId evidence/), "README states no messageId, no completion claim.", "P1")
      ],
      recommendation: "Add fixture tests with BEAI Runtime Overlay-like input to ensure final output does not leak labels."
    }),
    buildScenario({
      id: "S16-session-load-and-large-context-delay",
      title: "큰 Telegram 세션에서 지연/중단을 사용자가 이해할 수 있게 다루는가",
      userRisk: "세션이 커지거나 이전 turn이 미완료이면 사용자는 두 번째 메시지가 먹통이라고 느낀다.",
      checks: [
        makeCheck("doctor-incomplete-turn-detects", "Doctor detects incomplete turn patterns.", fileContains(files, root, doctor, /incomplete turn detected|telegram-direct-incomplete-turn/), "Doctor incomplete-turn detection exists.", "P1"),
        makeCheck("doctor-lane-delay-detects", "Doctor detects lane delay or queued processing patterns.", fileContains(files, root, doctor, /lane wait exceeded|queued_behind_active_work|run_started/), "Doctor delay detection exists.", "P1")
      ],
      recommendation: "Add a synthetic large-session fixture and UX wording for delayed-but-processing state."
    }),
    buildScenario({
      id: "S17-install-zip-intent-preservation",
      title: "첨부 zip 설치 의도가 memory/skill 후보로 오분류되지 않는가",
      userRisk: "사용자가 설치 파일을 보냈는데 시스템이 메모리 후보나 일반 조언으로 처리해 설치 흐름이 끊긴다.",
      checks: [
        makeCheck("install-candidate-session-state", "Runtime tracks install attachment candidates.", fileContains(files, root, runtimeIndex, /sessionInstallCandidates|sessionInstallIntents/), "Install candidate session maps exist.", "P1"),
        makeCheck("install-guide-surface", "Runtime has install guide/resume surfaces.", fileContains(files, root, runtimeIndex, /renderInstallGuideReply|renderInstallResumeReply/), "Install guide/resume surfaces exist.", "P1")
      ],
      recommendation: "Add attachment-intent fixture with zip metadata and Korean install request text."
    }),
    buildScenario({
      id: "S18-operational-notification-action-frame",
      title: "watchdog, heartbeat, cron dry-run, Knowledge Loop 후보가 사용자에게 모호한 행동 요청으로 보이지 않는가",
      userRisk: "사용자는 내부 후보나 dry-run 신호를 보고 지금 자신이 무엇을 해야 하는지 몰라 혼란을 겪는다.",
      checks: [
        makeCheck("operational-contract-exists", "Operational notification contract exists.", Boolean(operationalContract), "Operational notification contract JSON parses.", "P0"),
        makeCheck("dry-run-default-suppressed", "Non-actionable dry-runs default to notify=false.", operationalRules.dry_run_default_notify_false === true && operationalRules.watchdog_route_dry_run_default_suppressed === true, "Dry-run suppression rules are true.", "P0"),
        makeCheck("raw-internal-markers-forbidden", "Raw internal candidate markers are forbidden from user-visible notices.", forbiddenOperationalMarkers.includes("[검토 우선 / 비영구 메모]") && forbiddenOperationalMarkers.includes("BEAI watchdog route dry-run"), "Raw internal markers are forbidden.", "P0"),
        makeCheck("action-frame-required", "User-visible operational notices require action ownership framing.", operationalRules.user_visible_operational_notice_requires_action_frame === true && operationalRules.notification_must_separate_user_action_assistant_action_and_not_yet === true, "Action frame rules are true.", "P0"),
        makeCheck("cron-candidate-not-ready", "Cron candidate is not presented as cron-ready automation.", operationalRules.cron_candidate_is_not_cron_ready === true && operationalRules.automation_registration_requires_separate_approval === true, "Cron readiness and approval rules are true.", "P0"),
        makeCheck("operational-doc-user-language", "Operational notification doc explains no-user-action and action ownership in user language.", fileContains(files, root, operationalNotificationDoc, /사용자 조치 필요 없음/) && fileContains(files, root, operationalNotificationDoc, /제가 할 일/) && fileContains(files, root, operationalNotificationDoc, /아직 하지/), "User action, assistant action, and not-yet language are documented.", "P1"),
        makeCheck("operational-gate-in-package", "Operational notification gate is package-owned and read-only.", fileContains(files, root, operationalNotificationGate, /no OpenClaw core change/) && fileContains(files, root, operationalNotificationGate, /no cron, hook, or agent registration/), "Read-only gate boundaries are present.", "P1")
      ],
      recommendation: "Treat confusing watchdog/Knowledge Loop dry-run output as a package UX regression; suppress non-actionable notices or require action ownership framing."
    }),
    buildScenario({
      id: "S19-human-companion-quality",
      title: "BEAI 5식 동반 대화 품질이 말투가 아니라 런타임 계약으로 반영되는가",
      userRisk: "사용자는 비아이5에서는 이해받고 맥락이 살아 있다고 느끼지만, 패키지 적용 후에는 오래된 맥락, 과한 설명, 선택 부담, 검증 없는 단정 때문에 다시 일반 챗봇처럼 느낄 수 있다.",
      checks: [
        makeCheck("human-companion-contract-parses", "Human companion quality contract parses.", Boolean(humanCompanionQualityContract), "Human companion quality contract JSON parses.", "P0"),
        makeCheck("current-request-primary-anchor", "Current request remains the primary anchor.", humanCompanionRules.current_request_is_primary_anchor === true, "current_request_is_primary_anchor rule is true.", "P0"),
        makeCheck("prior-context-supporting-boundary", "Prior context supports but must not override current request.", humanCompanionRules.prior_context_supports_but_must_not_override_current_request === true, "prior context boundary rule is true.", "P0"),
        makeCheck("cognitive-load-reduction", "Responses must reduce cognitive load.", humanCompanionRules.response_must_reduce_cognitive_load === true, "cognitive load reduction rule is true.", "P0"),
        makeCheck("user-agency-preserved", "Responses preserve user agency and decision ownership.", humanCompanionRules.response_must_preserve_user_agency === true, "agency preservation rule is true.", "P0"),
        makeCheck("runtime-profile-present", "Runtime includes HumanCompanionQualityProfile.", fileContains(files, root, runtimeCore, /HumanCompanionQualityProfile/), "HumanCompanionQualityProfile exists in runtime core.", "P0"),
        makeCheck("runtime-builder-present", "Runtime builds human companion quality from current turn state.", fileContains(files, root, runtimeCore, /buildHumanCompanionQualityProfile/), "buildHumanCompanionQualityProfile exists.", "P0"),
        makeCheck("runtime-user-reality-frame", "Runtime preserves user reality before interpretation.", fileContains(files, root, runtimeCore, /userRealityFrame/) && humanCompanionRuntimeSymbols.includes("userRealityFrame"), "userRealityFrame exists in runtime and contract.", "P0"),
        makeCheck("runtime-burden-reducer", "Runtime reduces burden instead of expanding options.", fileContains(files, root, runtimeCore, /burdenReducer/) && humanCompanionRuntimeSymbols.includes("burdenReducer"), "burdenReducer exists in runtime and contract.", "P0"),
        makeCheck("runtime-conversation-asset-ledger", "Runtime separates accepted context from assistant-only interpretations.", fileContains(files, root, runtimeCore, /conversationAssetLedger/) && humanCompanionRuntimeSymbols.includes("conversationAssetLedger"), "conversationAssetLedger exists in runtime and contract.", "P0"),
        makeCheck("runtime-artifact-scene-model", "Runtime models artifact scene fit, not just artifact-first timing.", fileContains(files, root, runtimeCore, /artifactSceneModel/) && humanCompanionRuntimeSymbols.includes("artifactSceneModel"), "artifactSceneModel exists in runtime and contract.", "P1"),
        makeCheck("runtime-recovery-frame", "Runtime carries recovery behavior for misread repair.", fileContains(files, root, runtimeCore, /recoveryFrame/) && humanCompanionRuntimeSymbols.includes("recoveryFrame"), "recoveryFrame exists in runtime and contract.", "P1"),
        makeCheck("conversation-flow-intent-state-situation-rule", "Contract requires intent, conversation state, and situation tracking.", humanCompanionRules.conversation_flow_must_track_intent_state_and_situation === true, "conversation flow intent/state/situation rule is true.", "P0"),
        makeCheck("conversation-flow-fluid-context-rule", "Contract rejects mechanical context stuffing.", humanCompanionRules.context_must_move_fluidly_without_mechanical_stuffing === true, "fluid context selection rule is true.", "P0"),
        makeCheck("conversation-flow-correction-rule", "Contract requires correction signals to update the frame without defense.", humanCompanionRules.correction_signal_must_update_frame_without_defense === true, "correction signal frame-update rule is true.", "P0"),
        makeCheck("runtime-conversational-flow-core", "Runtime carries conversational flow core for natural intent/context motion.", fileContains(files, root, runtimeCore, /conversationalFlowCore/) && humanCompanionRuntimeSymbols.includes("conversationalFlowCore"), "conversationalFlowCore exists in runtime and contract.", "P0"),
        makeCheck("runtime-conversational-flow-rendered", "Runtime prompt context renders conversational flow core.", fileContains(files, root, runtimeCore, /conversational_flow_core:/), "conversational_flow_core overlay section exists.", "P1"),
        makeCheck("runtime-overlay-renders-quality-gate", "Runtime prompt context renders human companion quality gate.", fileContains(files, root, runtimeCore, /human_companion_quality:/), "human_companion_quality overlay section exists.", "P1"),
        makeCheck("human-companion-doc-quality-bar", "Korean document includes the canonical human quality bar.", fileContains(files, root, humanCompanionDoc, /응답 뒤 사용자의 현실이 더 선명해지고, 판단 부담이 줄며, 실제로 쓸 수 있는 무언가가 남았는가/), "Canonical human quality bar is documented.", "P1"),
        makeCheck("human-companion-doc-five-frames", "Korean document names the five BEAI 5 runtime frames.", fileContains(files, root, humanCompanionDoc, /userRealityFrame/) && fileContains(files, root, humanCompanionDoc, /burdenReducer/) && fileContains(files, root, humanCompanionDoc, /conversationAssetLedger/) && fileContains(files, root, humanCompanionDoc, /artifactSceneModel/) && fileContains(files, root, humanCompanionDoc, /recoveryFrame/), "Five runtime frames are documented.", "P1"),
        makeCheck("human-companion-doc-flow-naturalness", "Korean document explains conversational flow naturalness.", fileContains(files, root, humanCompanionDoc, /대화 흐름의 자연스러움/) && fileContains(files, root, humanCompanionDoc, /conversationalFlowCore/), "Conversational flow naturalness is documented.", "P1"),
        makeCheck("flow-gate-covers-human-companion", "Flow regression gate covers human companion quality.", fileContains(files, root, flowGate, /human_companion_quality_regression/), "Flow gate has human companion quality regression lane.", "P1")
      ],
      recommendation: "Treat BEAI 5 integration as runtime behavior: preserve user reality, reduce burden, promote only accepted context, fit artifacts to the scene, recover from misreads, and keep context moving naturally with intent, state, and situation."
    }),
    buildScenario({
      id: "S20-action-semantics-and-recovery-claim",
      title: "보고/완화/복구/검증의 의미가 섞여 사용자 정정까지 가는가",
      userRisk: "사용자가 오류 복구를 원했는데 시스템이 보고 형식 완화나 프롬프트 규칙 추가를 복구처럼 말하면, 사용자는 AI가 말뜻과 실제 행동을 구분하지 못한다고 느낀다.",
      checks: [
        makeCheck("action-semantics-contract-parses", "Action semantics contract parses.", Boolean(actionSemanticsQualityContract), "Action semantics contract JSON parses.", "P0"),
        makeCheck("recovery-claim-four-evidence-items", "Repair claims require reproduce/observe, cause, changed path, and same-condition reverification.", recoveryRequiredEvidence.includes("failure_path_reproduced_or_currently_observed") && recoveryRequiredEvidence.includes("cause_identified") && recoveryRequiredEvidence.includes("failing_path_changed") && recoveryRequiredEvidence.includes("same_condition_reverified"), `repair required evidence=${recoveryRequiredEvidence.join(",") || "none"}`, "P0"),
        makeCheck("recovery-forbidden-claims", "Recovery-like claims are forbidden without repair evidence.", recoveryForbiddenClaims.includes("복구했습니다") && recoveryForbiddenClaims.includes("해결했습니다") && recoveryForbiddenClaims.includes("fixed"), "Forbidden recovery claims exist.", "P0"),
        makeCheck("correction-trigger-this-is-recovery", "User correction trigger for '이게 복구야' is explicit.", correctionTriggers.includes("이게 복구야") && correctionTriggers.includes("상태 보고잖아"), "Correction trigger phrases exist.", "P0"),
        makeCheck("action-semantics-runtime-profile", "Runtime includes ActionSemanticsProfile.", fileContains(files, root, runtimeCore, /ActionSemanticsProfile/), "ActionSemanticsProfile exists in runtime core.", "P0"),
        makeCheck("action-semantics-runtime-builder", "Runtime builds action semantics from current user input.", fileContains(files, root, runtimeCore, /buildActionSemanticsProfile/), "buildActionSemanticsProfile exists.", "P0"),
        makeCheck("action-semantics-runtime-render", "Runtime prompt context renders action semantics.", fileContains(files, root, runtimeCore, /action_semantics:/), "action_semantics overlay section exists.", "P1"),
        makeCheck("doc-report-not-repair", "Korean doc says report-only is report, not repair.", fileContains(files, root, actionSemanticsDoc, /보고만 했으면 보고다/), "Report-only boundary is documented.", "P1"),
        makeCheck("doc-failure-path-reverify", "Korean doc says repair changes the failing path and verifies the same condition.", fileContains(files, root, actionSemanticsDoc, /실패 경로를 바꾸고 같은 조건에서 다시 성공/), "Repair evidence boundary is documented.", "P1"),
        makeCheck("flow-gate-covers-action-semantics", "Flow regression gate covers semantic action mismatch.", fileContains(files, root, flowGate, /semantic_action_mismatch/), "Flow gate has semantic action mismatch lane.", "P1")
      ],
      recommendation: "When user wording names an action, classify the actual performed action first. Only call it recovery after failing path change and same-condition re-verification; otherwise label it diagnosis, report, mitigation, prevention, partial action, or pending verification."
    }),
    buildScenario({
      id: "S21-friction-aware-gate",
      title: "안전장치가 사용자 속도감과 쾌적함을 과하게 떨어뜨리지 않는가",
      userRisk: "검증과 승인 철학을 모든 요청에 빡빡하게 적용하면 사용자는 AI에게 원하는 빠른 초안, 몰입감, 대화 리듬을 잃고 BEAI를 피곤한 절차로 느낀다.",
      checks: [
        makeCheck("friction-aware-contract-parses", "Friction-aware gate contract parses.", Boolean(frictionAwareGateQualityContract), "Friction-aware gate contract JSON parses.", "P0"),
        makeCheck("fast-lane-default", "Drafts and thinking default to fast lane.", frictionAwareRules.default_to_fast_lane_for_drafts_and_thinking === true && Boolean(frictionAwareLanes.fast_lane), "fast_lane rule and lane exist.", "P0"),
        makeCheck("quiet-checks-do-not-interrupt", "Quiet checks do not interrupt user flow.", frictionAwareRules.quiet_checks_should_not_interrupt_user_flow === true && Boolean(frictionAwareLanes.quiet_check), "quiet_check rule and lane exist.", "P0"),
        makeCheck("approval-only-at-risk-transition", "Approval is required only at real risk transitions.", frictionAwareRules.approval_required_only_at_risk_transition === true && Boolean(frictionAwareLanes.approval_gate), "approval gate rule and lane exist.", "P0"),
        makeCheck("post-action-verification-before-completion", "Post-action verification prevents completion overclaim.", frictionAwareRules.post_action_verification_prevents_completion_overclaim === true && Boolean(frictionAwareLanes.post_action_verify), "post_action_verify rule and lane exist.", "P0"),
        makeCheck("high-liability-not-automated", "High-liability actions are not automated.", frictionAwareRules.do_not_automate_high_liability_actions === true && Boolean(frictionAwareLanes.do_not_automate), "do_not_automate rule and lane exist.", "P0"),
        makeCheck("runtime-friction-lane-type", "Runtime includes FrictionGateLane.", fileContains(files, root, runtimeCore, /FrictionGateLane/), "FrictionGateLane exists in runtime core.", "P0"),
        makeCheck("runtime-friction-builder", "Runtime builds the friction-aware gate from current-turn signals.", fileContains(files, root, runtimeCore, /buildFrictionAwareGateProfile/), "buildFrictionAwareGateProfile exists.", "P0"),
        makeCheck("runtime-friction-render", "Runtime prompt context renders friction-aware gate guidance.", fileContains(files, root, runtimeCore, /friction_aware_gate:/), "friction_aware_gate overlay section exists.", "P1"),
        makeCheck("friction-doc-clutch-language", "Korean document preserves the clutch-not-brake UX principle.", fileContains(files, root, frictionAwareGateDoc, /BEAI는 브레이크가 아니라 클러치/), "Clutch UX principle is documented.", "P1"),
        makeCheck("flow-gate-covers-friction", "Flow regression gate covers friction-aware gate regressions.", fileContains(files, root, flowGate, /friction-aware-gate-overlay-rendered/) && fileContains(files, root, flowGate, /friction-aware-gate-config-present/), "Flow gate has friction-aware checks.", "P1")
      ],
      recommendation: "Default to speed for drafts, thinking, and read-only work. Raise friction only for external effects, destructive or durable state changes, repeated automation, high-liability domains, and completion claims that need evidence."
    }),
    buildScenario({
      id: "S22-control-center-readonly-status",
      title: "BEAI 구성요소 상태를 한곳에서 보되 관제판이 실행 권한을 넘지 않는가",
      userRisk: "구성요소가 많아질수록 source, verified, packaged, live, delivered, active automation 상태가 섞이면 사용자는 무엇을 믿어도 되는지 다시 추적해야 한다. 반대로 관제판이 곧바로 실행 버튼이 되면 승인 경계가 흐려진다.",
      checks: [
        makeCheck("control-center-contract-parses", "Control Center contract parses.", Boolean(controlCenterQualityContract), "Control Center contract JSON parses.", "P0"),
        makeCheck("control-center-readonly-default", "Control Center is read-only by default.", controlCenterRules.control_center_is_read_only_by_default === true, "Read-only default rule is true.", "P0"),
        makeCheck("control-center-state-separation", "Source, live, package, and release states must be separated.", controlCenterRules.source_live_package_release_states_must_be_separated === true, "State separation rule is true.", "P0"),
        makeCheck("control-center-candidates-not-active", "Workflow candidates are not reported as active automation.", controlCenterRules.workflow_candidates_must_not_be_reported_as_active_automation === true, "Candidate/active automation rule is true.", "P0"),
        makeCheck("control-center-tool-present", "Control Center status command exists.", fileContains(files, root, controlCenterTool, /schema:\s*"beai\.control_center\.v0_1"/), "Control Center tool emits v0.1 schema.", "P0"),
        makeCheck("control-center-tool-non-actions", "Control Center tool declares non-actions for live and external effects.", fileContains(files, root, controlCenterTool, /no Gateway restart/) && fileContains(files, root, controlCenterTool, /no Telegram send/) && fileContains(files, root, controlCenterTool, /no durable memory write/), "Non-action boundaries are present.", "P0"),
        makeCheck("control-center-required-outputs", "Control Center required outputs include versions, ledgers, verification, approval boundaries, and next action.", controlCenterOutputs.includes("runtime source version") && controlCenterOutputs.includes("runtime live version") && controlCenterOutputs.includes("state ledgers") && controlCenterOutputs.includes("verification reports") && controlCenterOutputs.includes("approval boundaries") && controlCenterOutputs.includes("next safe action"), "Required output set is present.", "P1"),
        makeCheck("control-center-doc-readonly", "Control Center Korean doc says v0.1 is read-only.", fileContains(files, root, controlCenterDoc, /보기 전용 관제판/) && fileContains(files, root, controlCenterDoc, /실행 버튼을 만들지 않는다/), "Read-only purpose is documented.", "P1"),
        makeCheck("control-center-package-verify", "Package verify runs Control Center status.", fileContains(files, root, "tools/beai-package-verify.mjs", /beai-control-center\.mjs/), "Package verify includes Control Center.", "P1"),
        makeCheck("control-center-flow-gate", "Flow regression gate covers Control Center regressions.", fileContains(files, root, flowGate, /control_center_state_confusion/) && fileContains(files, root, flowGate, /control_center_mutation_risk/), "Flow gate has Control Center regression checks.", "P1")
      ],
      recommendation: "Keep v0.1 as a read-only status board. Add approval-shaped actions only after source/live/package/release, workflow/automation, memory, delivery, and verification ledgers are consistently visible."
    }),
    buildScenario({
      id: "S23-workbench-essential-skills-source-candidate",
      title: "Workbench Essential Skills가 단순 문서가 아니라 source candidate 구조로 잡혔는가",
      userRisk: "핵심 작업 스킬을 말로만 정의하면 실제 패키지에서는 라우팅, 계약, 감사, 상태 표시가 분리되어 품질을 유지하지 못한다.",
      checks: [
        makeCheck("workbench-contract-parses", "Workbench contract parses.", Boolean(workbenchQualityContract), "Workbench contract JSON parses.", "P0"),
        makeCheck("workbench-five-studios", "Workbench contract lists five studios.", workbenchStudios.length === 5, `studio count=${workbenchStudios.length}`, "P0"),
        makeCheck("workbench-docs-present", "Workbench dossier, plan, and contract docs exist.", isFile(path.join(root, workbenchResearchDossier)) && isFile(path.join(root, workbenchDevelopmentPlan)) && isFile(path.join(root, workbenchContractDoc)), "Required Workbench docs are present.", "P1"),
        makeCheck("workbench-skills-in-manifest", "Five Workbench skills are listed in manifest.", workbenchSkillIds.every((id) => manifestSkillIds.has(id)), "Manifest contains all Workbench skill ids.", "P0"),
        makeCheck("workbench-essential-skills-manifest", "Manifest has essentialSkills source candidate section.", manifest?.essentialSkills?.id === "beai-workbench-essential-skills" && manifest?.essentialSkills?.status === "source-candidate", `essentialSkills status=${manifest?.essentialSkills?.status || "missing"}`, "P0"),
        makeCheck("workbench-audit-tool-present", "Workbench read-only audit tool exists.", isFile(path.join(root, workbenchAuditTool)), "Audit tool file exists.", "P0"),
        makeCheck("workbench-package-verify-wired", "Package verify runs Workbench skill audit.", fileContains(files, root, "tools/beai-package-verify.mjs", /beai-workbench-skill-audit\.mjs/), "Package verify includes Workbench audit.", "P1")
      ],
      recommendation: "Keep Workbench as a source candidate until contract, skill files, audit, Doctor, Control Center, and user scenario evidence all pass locally."
    }),
    buildScenario({
      id: "S24-visual-design-aesthetic-quality",
      title: "디자인 스킬이 정확성뿐 아니라 미감과 시각 완성도를 1차 품질로 다루는가",
      userRisk: "기능적으로 맞지만 못생긴 결과물은 실제 업무에서 쓰이지 않고, 사용자는 BEAI가 디자인 감각을 갖추지 못했다고 느낀다.",
      checks: [
        makeCheck("visual-skill-present", "Visual Design Studio skill exists.", isFile(path.join(root, visualDesignSkill)), "Visual Design Studio SKILL.md exists.", "P0"),
        makeCheck("visual-aesthetic-rule", "Contract requires aesthetic quality for design.", workbenchRules.visual_design_must_include_aesthetic_quality === true, "visual design aesthetic rule is true.", "P0"),
        makeCheck("visual-polish-pattern", "Visual skill has visual polish and critique patterns.", fileContains(files, root, visualDesignSkill, /second_pass_visual_polish/) && fileContains(files, root, visualDesignSkill, /critique_visual_layout/), "Visual polish and critique patterns are present.", "P0"),
        makeCheck("visual-taste-language", "Visual skill explicitly checks whether the output looks good.", fileContains(files, root, visualDesignSkill, /보기 좋은가/) && fileContains(files, root, visualDesignSkill, /타이포그래피/) && fileContains(files, root, visualDesignSkill, /색상/), "Aesthetic, typography, and color checks are present.", "P0"),
        makeCheck("visual-no-overclaim", "Visual skill forbids claiming production-ready design without visual QA.", fileContains(files, root, visualDesignSkill, /Do not say production-ready|production-ready/) && fileContains(files, root, visualDesignSkill, /visual QA/), "Visual overclaim boundary is present.", "P1")
      ],
      recommendation: "Keep visual taste as an explicit gate: beautiful, readable, branded, editable, and medium-fit before calling a design client-ready."
    }),
    buildScenario({
      id: "S25-research-evidence-boundary",
      title: "리서치 스킬이 출처 요약이 아니라 판단 가능한 근거 바닥을 만드는가",
      userRisk: "검색 결과를 그럴듯하게 요약하면 사용자는 최신성, 반대 근거, 주장/추론 경계를 놓치고 잘못된 판단을 할 수 있다.",
      checks: [
        makeCheck("research-skill-present", "Research Evidence Studio skill exists.", isFile(path.join(root, researchEvidenceSkill)), "Research Evidence Studio SKILL.md exists.", "P0"),
        makeCheck("research-claim-fact-inference", "Research skill separates claim, fact, and inference.", fileContains(files, root, researchEvidenceSkill, /claim\/fact\/inference|claim, fact, inference/), "Claim/fact/inference separation is present.", "P0"),
        makeCheck("research-counter-evidence", "Research skill requires counter-evidence.", fileContains(files, root, researchEvidenceSkill, /counter-evidence|counter evidence/i), "Counter-evidence requirement is present.", "P0"),
        makeCheck("research-source-registry", "Research skill builds a source registry.", fileContains(files, root, researchEvidenceSkill, /source registry/), "Source registry is present.", "P0"),
        makeCheck("research-evidence-strength", "Research skill grades evidence strength and unresolved checks.", fileContains(files, root, researchEvidenceSkill, /evidence strength/) && fileContains(files, root, researchEvidenceSkill, /unresolved checks/), "Evidence strength and unresolved checks are present.", "P1")
      ],
      recommendation: "Require source registry, recency, counter-evidence, and claim/fact/inference separation before a research result influences decisions."
    }),
    buildScenario({
      id: "S26-data-insight-statistical-boundary",
      title: "데이터 분석 스킬이 차트 생성보다 재현성과 통계 한계를 먼저 지키는가",
      userRisk: "그럴듯한 차트와 수치가 계산 오류, 결측치, 상관/인과 혼동, 과장된 해석을 숨기면 의사결정 위험이 커진다.",
      checks: [
        makeCheck("data-skill-present", "Data Insight Lab skill exists.", isFile(path.join(root, dataInsightSkill)), "Data Insight Lab SKILL.md exists.", "P0"),
        makeCheck("data-formula-integrity", "Data skill audits formulas and recalculation.", fileContains(files, root, dataInsightSkill, /audit_formula_integrity/) && fileContains(files, root, dataInsightSkill, /recalculation|recalc/i), "Formula integrity and recalculation checks are present.", "P0"),
        makeCheck("data-cleaning-log", "Data skill requires a cleaning log.", fileContains(files, root, dataInsightSkill, /cleaning log/), "Cleaning log requirement is present.", "P0"),
        makeCheck("data-correlation-causation", "Data skill separates correlation and causation.", fileContains(files, root, dataInsightSkill, /correlation/) && fileContains(files, root, dataInsightSkill, /causation/), "Correlation/causation boundary is present.", "P0"),
        makeCheck("data-statistical-boundary", "Data skill requires statistical limitation boundary.", fileContains(files, root, dataInsightSkill, /statistical boundary|statistical limitation|statistical proof/i), "Statistical boundary is present.", "P1")
      ],
      recommendation: "Treat data work as reproducible judgment support: profile, clean, verify formulas, state limits, then visualize."
    }),
    buildScenario({
      id: "S27-presentation-document-artifact-gates",
      title: "발표자료와 문서 스킬이 텍스트 초안이 아니라 실제 산출물 품질 게이트를 갖는가",
      userRisk: "PPT나 문서가 내용상 맞아도 화면, 렌더링, 독자 흐름, 제출 형식이 깨지면 사용자는 바로 쓸 수 없다.",
      checks: [
        makeCheck("presentation-skill-present", "Presentation Studio skill exists.", isFile(path.join(root, presentationSkill)), "Presentation Studio SKILL.md exists.", "P0"),
        makeCheck("document-skill-present", "Document Craft Studio skill exists.", isFile(path.join(root, documentCraftSkill)), "Document Craft Studio SKILL.md exists.", "P0"),
        makeCheck("presentation-render-qa", "Presentation skill requires render or screenshot QA.", fileContains(files, root, presentationSkill, /render|screenshot/i) && fileContains(files, root, presentationSkill, /QA/), "Presentation render/screenshot QA is present.", "P0"),
        makeCheck("presentation-not-text-only", "Presentation skill forbids calling text-only outlines finished slides.", fileContains(files, root, presentationSkill, /text-only outline/) && fileContains(files, root, presentationSkill, /finished deck/), "Text-only deck boundary is present.", "P1"),
        makeCheck("document-reader-test", "Document skill requires reader test and structure.", fileContains(files, root, documentCraftSkill, /reader_test/) && fileContains(files, root, documentCraftSkill, /structure/), "Reader test and structure are present.", "P0"),
        makeCheck("document-submission-boundary", "Document skill separates draft from submitted/approved document.", fileContains(files, root, documentCraftSkill, /submitted|approved/i) && fileContains(files, root, documentCraftSkill, /separate approval|Requires separate approval/), "Submission boundary is present.", "P1")
      ],
      recommendation: "Keep PPT and document work artifact-shaped: story, layout, render/readability QA, format boundary, and human approval before external use."
    }),
    buildScenario({
      id: "S28-workbench-handoff-pattern-depth",
      title: "Workbench Studio가 다음 사람이나 도구가 이어받을 수 있는 handoff-ready 패턴을 갖는가",
      userRisk: "산출물이 좋아 보여도 의사결정, 가정, 자산 계획, 검증 상태가 남지 않으면 다음 세션이나 사람이 이어받지 못해 실제 업무 자산이 되기 어렵다.",
      checks: [
        makeCheck("workbench-handoff-rule", "Workbench contract requires handoff state.", workbenchRules.studio_skills_must_include_handoff_state === true, "handoff state rule is true.", "P0"),
        makeCheck("workbench-required-section-handoff", "Handoff State is a required skill section.", Array.isArray(workbenchQualityContract?.required_skill_sections) && workbenchQualityContract.required_skill_sections.includes("Handoff State"), "Handoff State section is required.", "P0"),
        makeCheck("workbench-round4-dossier", "Research dossier includes Round 4 external pattern review.", fileContains(files, root, workbenchResearchDossier, /Round 4\. Community-adopted skill libraries and handoff patterns/), "Round 4 dossier section exists.", "P1"),
        makeCheck("workbench-pattern-depth", "Every Studio has at least nine contract patterns.", workbenchStudios.length === 5 && workbenchStudios.every((studio) => Array.isArray(studio.patterns) && studio.patterns.length >= 9), "All five studios have at least nine patterns.", "P0"),
        makeCheck("visual-handoff-section", "Visual skill has Handoff State.", fileContains(files, root, visualDesignSkill, /^## Handoff State$/m), "Visual Handoff State exists.", "P0"),
        makeCheck("presentation-handoff-section", "Presentation skill has Handoff State.", fileContains(files, root, presentationSkill, /^## Handoff State$/m), "Presentation Handoff State exists.", "P0"),
        makeCheck("document-handoff-section", "Document skill has Handoff State.", fileContains(files, root, documentCraftSkill, /^## Handoff State$/m), "Document Handoff State exists.", "P0"),
        makeCheck("research-handoff-section", "Research skill has Handoff State.", fileContains(files, root, researchEvidenceSkill, /^## Handoff State$/m), "Research Handoff State exists.", "P0"),
        makeCheck("data-handoff-section", "Data skill has Handoff State.", fileContains(files, root, dataInsightSkill, /^## Handoff State$/m), "Data Handoff State exists.", "P0")
      ],
      recommendation: "Treat handoff readiness as a BEAI differentiator: every Studio must leave decisions, assumptions, QA state, and next checks in a form that a human or later tool can continue."
    }),
    buildScenario({
      id: "S29-external-reach-layer-source-candidate",
      title: "External Reach Layer가 외부 채널 접근을 만능으로 과장하지 않고 검증 가능한 계층으로 잡혔는가",
      userRisk: "외부 URL, X, Reddit, YouTube, GitHub를 모두 바로 읽을 수 있다고 과장하면 사용자는 계정/쿠키/로그인/정책 제한과 출처 검증 상태를 놓친다.",
      checks: [
        makeCheck("external-reach-contract-parses", "External Reach contract parses.", Boolean(externalReachQualityContract), "External Reach contract JSON parses.", "P0"),
        makeCheck("external-reach-doc-present", "External Reach Korean doc exists.", isFile(path.join(root, externalReachDoc)), "External Reach doc is present.", "P1"),
        makeCheck("external-reach-doctor-present", "External Reach read-only doctor exists.", isFile(path.join(root, externalReachDoctor)), "External Reach doctor file exists.", "P0"),
        makeCheck("external-reach-package-verify-wired", "Package verify runs External Reach doctor.", fileContains(files, root, "tools/beai-package-verify.mjs", /beai-external-reach-doctor\.mjs/), "Package verify includes External Reach doctor.", "P1"),
        makeCheck("external-reach-control-center-wired", "Control Center reports External Reach status.", fileContains(files, root, controlCenterTool, /externalReach/), "Control Center has External Reach section.", "P1"),
        makeCheck("external-reach-readonly-rule", "External Reach is read-only by default.", externalReachRules.external_reach_is_read_only_by_default === true, "read-only default rule is true.", "P0"),
        makeCheck("external-reach-public-channels", "Public web, GitHub, YouTube, and RSS are modeled.", ["public_web", "github", "youtube", "rss"].every((id) => externalReachChannelIds.has(id)), "Public channels are present.", "P0"),
        makeCheck("external-reach-social-approval-gate", "X, Reddit, and Meta-family channels are approval-gated.", externalReachChannels.filter((channel) => ["x_twitter", "reddit", "social_meta"].includes(channel.id)).every((channel) => channel.approvalRequired === true), "Social/account-dependent channels are approval-gated.", "P0"),
        makeCheck("external-reach-source-registry", "External Reach contract defines source registry fields.", Array.isArray(externalReachQualityContract?.source_registry_fields) && externalReachQualityContract.source_registry_fields.includes("backend_status") && externalReachQualityContract.source_registry_fields.includes("approval_state") && externalReachQualityContract.source_registry_fields.includes("limitations"), "Source registry includes backend status, approval state, and limitations.", "P0"),
        makeCheck("research-studio-external-reach", "Research Evidence Studio references External Reach registry and approval boundary.", fileContains(files, root, researchEvidenceSkill, /External Reach/) && fileContains(files, root, researchEvidenceSkill, /account login|browser cookie/i), "Research Studio includes External Reach workflow and approval boundary.", "P0")
      ],
      recommendation: "Keep External Reach as read-only, source-registry-first infrastructure. Public channels can be checked quickly; account or cookie-dependent channels stay behind approval."
    })
  ];

  const summary = {
    total: scenarios.length,
    pass: scenarios.filter((scenario) => scenario.status === "pass").length,
    partial: scenarios.filter((scenario) => scenario.status === "partial").length,
    fail: scenarios.filter((scenario) => scenario.status === "fail").length,
    p0Failures: scenarios.flatMap((scenario) => scenario.checks.filter((check) => check.status === "fail" && check.severity === "P0").map((check) => `${scenario.id}:${check.id}`)),
    p1Failures: scenarios.flatMap((scenario) => scenario.checks.filter((check) => check.status === "fail" && check.severity === "P1").map((check) => `${scenario.id}:${check.id}`))
  };

  return {
    schema: "beai.user_scenario_audit.v0_1",
    generated_at: new Date().toISOString(),
    package_root: root,
    status: summary.p0Failures.length > 0 ? "fail" : summary.p1Failures.length > 0 ? "partial" : "pass",
    summary,
    scenarios,
    not_performed: [
      "no durable memory write",
      "no OpenClaw core change",
      "no Gateway or Telegram config mutation",
      "no cron, hook, or agent registration",
      "no external send",
      "no release packaging",
      "no live Telegram roundtrip"
    ]
  };
}

function renderMarkdown(report) {
  const lines = [];
  lines.push("# BEAI User Scenario Audit");
  lines.push("");
  lines.push(`Generated at: ${report.generated_at}`);
  lines.push(`Status: ${report.status}`);
  lines.push(`Package root: ${report.package_root}`);
  lines.push("");
  lines.push("## Summary");
  lines.push("");
  lines.push(`- total: ${report.summary.total}`);
  lines.push(`- pass: ${report.summary.pass}`);
  lines.push(`- partial: ${report.summary.partial}`);
  lines.push(`- fail: ${report.summary.fail}`);
  lines.push(`- P0 failures: ${report.summary.p0Failures.length ? report.summary.p0Failures.join(", ") : "none"}`);
  lines.push(`- P1 failures: ${report.summary.p1Failures.length ? report.summary.p1Failures.join(", ") : "none"}`);
  lines.push("");
  lines.push("## Scenarios");
  lines.push("");
  for (const scenario of report.scenarios) {
    lines.push(`### ${scenario.id} - ${scenario.title}`);
    lines.push("");
    lines.push(`- status: ${scenario.status}`);
    lines.push(`- user risk: ${scenario.userRisk}`);
    lines.push(`- recommendation: ${scenario.recommendation}`);
    lines.push("");
    for (const check of scenario.checks) {
      lines.push(`- ${check.status.toUpperCase()} [${check.severity}] ${check.id}: ${check.description}`);
      lines.push(`  - evidence: ${check.evidence}`);
    }
    lines.push("");
  }
  lines.push("## Not Performed");
  lines.push("");
  for (const item of report.not_performed) lines.push(`- ${item}`);
  lines.push("");
  return `${lines.join("\n")}\n`;
}

function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    process.stdout.write(usage());
    return;
  }
  if (!["json", "md"].includes(options.format)) {
    throw new Error("--format must be json or md");
  }
  const root = resolveCapabilityRoot(options.root);
  const report = buildReport(root);
  const rendered = options.format === "json" ? `${JSON.stringify(report, null, 2)}\n` : renderMarkdown(report);
  if (options.output) {
    const outputPath = path.resolve(options.output);
    ensureOutputPath(outputPath);
    fs.writeFileSync(outputPath, rendered, "utf8");
  }
  if (options.stdout || !options.output) {
    process.stdout.write(rendered);
  }
}

try {
  main();
} catch (error) {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
}
