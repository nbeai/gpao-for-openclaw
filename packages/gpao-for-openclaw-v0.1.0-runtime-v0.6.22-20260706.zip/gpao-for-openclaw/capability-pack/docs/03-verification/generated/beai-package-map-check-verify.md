# BEAI Package Map Check

Generated at: 2026-07-04T14:12:38.589Z
Status: pass
Package root: /Users/jyp/Developer/BEAI/beai-package-for-openclaw

## Map

- schema: beai.package_module_map.v0_1
- domains: 10
- modules: 34
- doc: present (docs/BEAI-PACKAGE-MODULE-MAP-v0.1-ko.md)

## Domains

- runtime_layer: 1
- control_and_state: 2
- doctor_and_repair: 3
- verification_gates: 6
- knowledge_loop: 1
- workbench_studios: 7
- external_reach: 1
- operating_skills: 5
- contracts_and_policies: 6
- distribution_release: 2

## Issues

- none

