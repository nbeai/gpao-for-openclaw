# BEAI Knowledge Loop Retrieval Index

Schema: beai.knowledge_loop.retrieval_index.v0_1
Mode: manual-v0.1-local-index
Record count: 1
Skipped count: 33
Non-record helper count: 2

## 보고 완화를 오류 복구로 오분류한 실제 사용자 불신 장면

- id: action-semantics-recovery-claim-20260703
- source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST
- input_family: internal_work_record
- status: review-ready-not-automated
- path: /Users/jyp/Developer/BEAI/beai-package-for-openclaw/capability-pack/docs/03-verification/generated/knowledge-loop-action-semantics-recovery-claim-20260703.json
- terms: action, message, not, semantics, 사용자는, calendar, claim, cron, git, package, record, recovery, runtime, source, 복구로, 복구야, 완화를, assistant는, gate, openclaw
- aliases: recovery claim gate, action semantics, semantic action mismatch, 보고 완화와 복구 혼동, 이게 복구야
- query_examples: 복구라고 말하려면 어떤 증거가 필요하지? / 보고 완화를 복구로 말하는 문제를 어떻게 막지? / Action Semantics Contract가 왜 필요한가?
- korean_terms: 복구, 보고, 완화, 검증, 예방, 실패 경로, 같은 조건 재검증
- current_judgment_impact: high 5, medium 0, low 0

## Safety

- memory_write_allowed: false
- cron_or_hook_allowed: false
- external_send_allowed: false
- release_packaging_allowed: false
- retrieval_server_started: false
