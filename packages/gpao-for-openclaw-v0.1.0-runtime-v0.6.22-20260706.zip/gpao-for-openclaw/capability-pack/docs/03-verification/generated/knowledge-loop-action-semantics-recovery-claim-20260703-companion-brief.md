# 보고 완화를 오류 복구로 오분류한 실제 사용자 불신 장면

Source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST
Mode: manual-v0.1-companion-brief

## Summary

No summary provided.

## Reality Signals

- 사용자는 남은 경고를 어떻게 처리할지와 자동 메시지 가독성 개선을 요청했다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- assistant는 처음에 Calendar, git status, plugin 조회 경고가 사용자에게 짧게 보이도록 만드는 보고 완화와 cron prompt 규칙 변경을 '반영'으로 보고했다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- 사용자는 '이게 오류 복구야? 이건 그냥 상태 보고잖아. 오류면 복구를 해야하는거 아냐?'라고 정정했다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Key Decisions

- 오류 복구는 상태 보고나 표시 완화가 아니라 원인 확인, 실패 경로 수정, 재검증까지 포함해야 한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- 사용자는 이 실패를 '사용자들이 AI 보고 머리가 나쁘다고 말하는 부분'으로 규정했고, BEAI Package 업그레이드 소재로 삼으라고 했다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Definition Changes

- 사용자는 이 실패를 '사용자들이 AI 보고 머리가 나쁘다고 말하는 부분'으로 규정했고, BEAI Package 업그레이드 소재로 삼으라고 했다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Risks And Traps

- 경고를 덜 보기 흉하게 만들거나 프롬프트 규칙을 추가한 일을 '복구'라고 부르면 사용자는 말뜻을 못 알아들은 것으로 느낀다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- cron 본문에 규칙이 들어갔는지 확인하는 것은 복구 검증이 아니다. 실패 조건에서 다시 성공하는지 확인해야 한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Evidence

- message 5543: reporting/readability mitigation was reported as reflected (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- message 5544: user corrected that this was not error recovery (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- message 5546: assistant reclassified and performed actual repair checks (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- message 5549: upgrade analysis identified missing semantic-action alignment gate (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Knowledge Candidates

- 복구 claim은 실패 경로 관찰, 원인 특정, 실패 경로 변경, 같은 조건 재검증을 모두 요구하는 gate가 있어야 한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- 상태 라벨 매핑: diagnose=원인/범위 확인, report=상태 설명, mitigate=노출/소음/영향 완화, repair=실패 경로 변경+같은 조건 재검증, verify=증거 확인, prevent=재발 방지 규칙/테스트. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- 정정 신호 escalator: '이게 복구야?', '상태 보고잖아', '오류면 복구해야지'가 나오면 기존 프레임을 폐기하고 실제 요청 행위로 재분류한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Review Needed

- 복구 claim은 실패 경로 관찰, 원인 특정, 실패 경로 변경, 같은 조건 재검증을 모두 요구하는 gate가 있어야 한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- 상태 라벨 매핑: diagnose=원인/범위 확인, report=상태 설명, mitigate=노출/소음/영향 완화, repair=실패 경로 변경+같은 조건 재검증, verify=증거 확인, prevent=재발 방지 규칙/테스트. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- 정정 신호 escalator: '이게 복구야?', '상태 보고잖아', '오류면 복구해야지'가 나오면 기존 프레임을 폐기하고 실제 요청 행위로 재분류한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Current Judgment Impact

- affecting_current_judgment: 5
- high: 5
- medium: 0
- low: 0
- high: 복구 claim은 실패 경로 관찰, 원인 특정, 실패 경로 변경, 같은 조건 재검증을 모두 요구하는 gate가 있어야 한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- high: 상태 라벨 매핑: diagnose=원인/범위 확인, report=상태 설명, mitigate=노출/소음/영향 완화, repair=실패 경로 변경+같은 조건 재검증, verify=증거 확인, prevent=재발 방지 규칙/테스트. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- high: 정정 신호 escalator: '이게 복구야?', '상태 보고잖아', '오류면 복구해야지'가 나오면 기존 프레임을 폐기하고 실제 요청 행위로 재분류한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- high: BEAI Package에 Action Semantics Contract와 Recovery Claim Gate를 추가하고 runtime overlay에 action_semantics를 렌더링한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- high: user-scenario audit에 보고 완화를 복구로 말하지 않는 시나리오를 추가하고 flow regression gate에 semantic_action_mismatch lane을 추가한다. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Next Action Candidates

- Add Action Semantics Contract to package manifest and regression gates. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- Render action_semantics in BEAI Runtime prompt context. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- Regenerate Knowledge Loop retrieval index with this source record. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## Not Yet Scope

- Do not mutate OpenClaw core from this source record. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- Do not register cron, hooks, Gateway config, or public release automation from this source record. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)
- Do not claim live deployment until runtime package candidate is separately applied and verified. (source: telegram-direct:8601204821 messages 5541-5549, 2026-07-03 KST)

## User-Language Retrieval

- aliases: recovery claim gate, action semantics, semantic action mismatch, 보고 완화와 복구 혼동, 이게 복구야
- query_examples: 복구라고 말하려면 어떤 증거가 필요하지? / 보고 완화를 복구로 말하는 문제를 어떻게 막지? / Action Semantics Contract가 왜 필요한가?
- korean_terms: 복구, 보고, 완화, 검증, 예방, 실패 경로, 같은 조건 재검증

## Next Action

Review the classified candidates before any memory, automation, connector, or release action.

## Boundaries

- memory_status: review-required-no-durable-write
- package_status: action-semantics-upgrade-candidate
- automation_status: not-activated
- memory_write_allowed: false
- cron_or_hook_allowed: false
- external_send_allowed: false
- release_packaging_allowed: false
