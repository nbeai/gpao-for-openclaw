# BEAI User Scenario Audit

Generated at: 2026-07-02T11:34:51.141Z
Status: fail
Package root: /Users/jyp/Developer/BEAI/beai-package-for-openclaw/capability-pack

## Summary

- total: 17
- pass: 14
- partial: 1
- fail: 2
- P0 failures: S10-runtime-package-file-truth:package-files-match-dist-files, S11-package-default-vs-local-live-evidence:manifest-no-registered-automations-as-default, S11-package-default-vs-local-live-evidence:cap-readme-local-evidence-separated
- P1 failures: S08-doctor-help-and-user-control:doctor-help-implemented

## Scenarios

### S01-install-first-run-expectation - 첫 설치 사용자가 stable one-command install로 오해하지 않는가

- status: pass
- user risk: 사용자가 alpha package를 production-ready installer로 오해하면 설치 실패, rollback 부재, 지원 기대치 mismatch가 생긴다.
- recommendation: Keep alpha wording visible until clean-environment install, rollback, and ClawHub validation are verified.

- PASS [P0] root-readme-alpha-staging: Root README keeps alpha/public staging wording.
  - evidence: README contains alpha public staging wording.
- PASS [P0] root-readme-not-production: Root README rejects production-ready installer wording.
  - evidence: README warns against stable one-command installer claims.
- PASS [P1] runtime-install-surface-present: Runtime package declares OpenClaw install surface.
  - evidence: package.json has openclaw.install.clawhubSpec.

### S02-telegram-normal-reply-not-replaced - Telegram 일반 요청이 BEAI 표면 응답으로 대체되지 않는가

- status: pass
- user risk: 사용자는 질문에 대한 답 대신 승인/복구/상태 안내만 받아 대화가 막힌 것처럼 느낄 수 있다.
- recommendation: Add runtime-level fixture simulation later; current package has static and contract guards.

- PASS [P0] observer-only-runtime-evidence: Runtime records observer-only deferral for Telegram direct hard surfaces.
  - evidence: Runtime contains deferral evidence.
- PASS [P0] observer-only-contract: Delivery contract declares non-install Telegram surfaces observer-only.
  - evidence: Contract rule is true.
- PASS [P1] flow-gate-covers-observer-only: Regression gate includes Telegram direct hard surface guard.
  - evidence: Flow gate has regression lane.

### S03-telegram-completion-without-message-id - 내부 final이나 생성된 답변만으로 Telegram 완료를 주장하지 않는가

- status: pass
- user risk: 사용자는 실제로 메시지를 못 받았는데 시스템이 완료라고 말하는 가장 치명적인 신뢰 손상을 겪는다.
- recommendation: Keep messageId evidence mandatory; do not downgrade this to a warning.

- PASS [P0] internal-final-not-delivery: Contract says internal final_answer is not delivery.
  - evidence: Contract rule is true.
- PASS [P0] message-id-required: Contract requires messageId for Telegram direct completion.
  - evidence: Contract rule is true.
- PASS [P0] runtime-ledger-generated-unverified: Runtime records generated response as unverified until messageId.
  - evidence: Runtime generated-response ledger note is present.

### S04-repeated-footer-and-stale-handle - 오래된 확인 문구가 답변 마지막에 반복되지 않는가

- status: pass
- user risk: 사용자 지시를 무시하는 것처럼 보이고, 이전 작업의 맥락이 현재 답변을 오염시킨다.
- recommendation: Keep this in scenario audit because it was a real user trust failure, not a cosmetic wording issue.

- PASS [P0] footer-sanitizer-present: Runtime has repeated footer sanitizer.
  - evidence: Sanitizer function is present.
- PASS [P0] forced-footer-rule-inverted: Runtime guidance forbids repeated decision-handle footer.
  - evidence: Inverted guard text is present.
- PASS [P1] stale-forced-rule-not-rendered-raw: Old raw forced-footer instruction is not rendered directly.
  - evidence: No raw quoted forced-footer rule remains.

### S05-current-request-after-session-transition - 세션 전환 후 오래된 작업이 현재 요청을 덮지 않는가

- status: pass
- user risk: 사용자는 방금 말한 요청 대신 이전 핸들, 이전 도메인, 이전 계획이 답변에 붙는 불편을 겪는다.
- recommendation: Add fixture tests for numeric Telegram transcript and handoff overlay in the runtime package test suite.

- PASS [P0] current-input-render-anchor: Runtime overlay renders currentTurn.cleanInput.
  - evidence: current_input render anchor exists.
- PASS [P1] telegram-transcript-latest-user-fix: Runtime has Telegram transcript/latest user extraction logic.
  - evidence: Current-input extraction markers are present.
- PASS [P1] handoff-seed-sanitized: Handoff/session seed closure handle is sanitized.
  - evidence: Handoff seed sanitizer path exists.

### S06-long-work-visible-progress - 긴 작업 중 사용자가 침묵으로 느끼지 않도록 progress 기준이 있는가

- status: pass
- user risk: 작업은 진행 중이어도 Telegram 사용자는 멈춤, 먹통, 무시로 느낀다.
- recommendation: The contract exists; later live verification should prove progress actually reaches the source conversation.

- PASS [P1] quick-first-status-contract: Delivery contract requires quick first status.
  - evidence: Contract rule is true.
- PASS [P1] long-running-progress-contract: Delivery contract requires visible progress for long-running work.
  - evidence: Contract rule is true.
- PASS [P1] doctor-detects-progress-gap: Doctor issue code detects long-running visible progress gap.
  - evidence: Doctor issue code is present.

### S07-approval-friction-and-auto-mutation - 승인 경계가 안전하지만 과도한 마찰이 되지 않는가

- status: pass
- user risk: 승인이 필요한 작업과 읽기/점검이 섞이면 사용자는 매번 막히거나 반대로 위험한 자동 실행을 겪는다.
- recommendation: Keep read-only checks auto-proceeding, but require explicit approval for cron, Gateway, config, memory, external send, and release actions.

- PASS [P1] safe-but-pleasant-policy: Manifest keeps safe-but-pleasant policy.
  - evidence: Manifest includes safe-but-pleasant wording.
- PASS [P0] cron-default-not-auto: Root README says package does not create cron jobs automatically.
  - evidence: Root README excludes automatic cron creation.
- PASS [P0] automation-approval-boundary: Knowledge Loop doc keeps auto-capture separate from approval.
  - evidence: Auto-capture boundary exists.

### S08-doctor-help-and-user-control - 사용자가 Doctor 도움말만 보려다 실제 진단이 실행되지 않는가

- status: partial
- user risk: 도움말 확인이 상태 조회나 진단 실행으로 이어지면 도구 신뢰가 낮아진다.
- recommendation: If this fails in live CLI, implement --help as usage-only and exit before any OpenClaw probe.

- FAIL [P1] doctor-help-implemented: Doctor handles --help or -h before diagnosis.
  - evidence: Help handling text should exist.
- PASS [P2] doctor-mode-check-visible: Doctor exposes explicit mode/check language.
  - evidence: Mode/check language is present.

### S09-doctor-freshness-and-stale-log-risk - Doctor가 과거 로그를 현재 장애처럼 과장하지 않는가

- status: pass
- user risk: 이미 복구된 문제를 현재 장애로 보고하면 사용자가 불필요한 재시작이나 설정 변경을 하게 된다.
- recommendation: Add evidence timestamp/window to every log-derived issue and lower stale findings to review/historical_signal.

- PASS [P1] freshness-language-present: Doctor contains freshness/window language.
  - evidence: Freshness language is present if true.
- PASS [P1] connected-not-roundtrip-separated: Doctor separates connected from roundtrip verified.
  - evidence: Connected-but-not-roundtrip issue exists.

### S10-runtime-package-file-truth - 실제 npm pack 파일 목록이 의도한 dist 패키지와 일치하는가

- status: fail
- user risk: release note, README, dist 파일이 빠지거나 다른 파일이 들어가 설치자가 다른 내용을 받는다.
- recommendation: Align package.json and package.dist.json, then add npm pack dry-run output to the regression gate.

- PASS [P0] package-json-readable: Runtime package.json can be parsed.
  - evidence: package.json parse result exists.
- PASS [P0] package-dist-readable: Runtime package.dist.json can be parsed.
  - evidence: package.dist.json parse result exists.
- FAIL [P0] package-files-match-dist-files: package.json files match package.dist.json files.
  - evidence: missingFromPackage=RELEASE-NOTES-v0.6.17-ko.md extraInPackage=none

### S11-package-default-vs-local-live-evidence - 새 사용자에게 기본 설치 기능과 윤의 로컬 적용 증거가 섞여 보이지 않는가

- status: fail
- user risk: 패키지를 설치하면 cron, watchdog, persistent lane이 이미 켜지는 것처럼 오해할 수 있다.
- recommendation: Move local cron UUIDs and force-run evidence into local verification docs, not public/default capability manifest.

- FAIL [P0] manifest-no-registered-automations-as-default: Capability manifest does not list local registeredAutomations as default package state.
  - evidence: registeredAutomations should be moved to local evidence if present.
- FAIL [P0] cap-readme-local-evidence-separated: Capability README clearly says local automation evidence is not default install.
  - evidence: README separates local evidence from default install if true.

### S12-clean-environment-and-clawhub-validation - 깨끗한 환경에서 설치/검증 경로가 닫혀 있는가

- status: pass
- user risk: 개발자 환경에서는 되지만 새 사용자의 OpenClaw에서는 설치, hook, dependency, route가 실패할 수 있다.
- recommendation: Do not call public install ready until clean environment install and ClawHub validation are actually run.

- PASS [P0] root-readme-clean-env-needed: Root README says clean OpenClaw environment checks are still needed.
  - evidence: Clean environment requirement is documented.
- PASS [P0] clawhub-validation-not-overclaimed: Package does not claim ClawHub validation is closed.
  - evidence: No ClawHub validation pass claim found.

### S13-memory-capture-without-auto-approval - 메모리 후보가 사용자 승인 없이 장기 기억으로 승격되지 않는가

- status: pass
- user risk: 사용자 말이나 작업 흔적이 원치 않게 장기 기억 또는 자동화 판단으로 굳어진다.
- recommendation: Keep auto-capture review-only and route durable memory to explicit approval.

- PASS [P0] approved-requires-user-approval: Approved state requires explicit user approval.
  - evidence: Approved state boundary exists.
- PASS [P1] memory-current-judgment-impact: Knowledge Loop separates current judgment impact.
  - evidence: current_judgment_impact exists.

### S14-korean-status-wording - 한국어 답변이 상태를 과장하거나 번역투로 불편하게 만들지 않는가

- status: pass
- user risk: 검증/적용/전송/배포가 섞이면 사용자는 실제 상태를 잘못 이해한다.
- recommendation: Use the Korean standard for reports and Telegram closeouts, especially after failures.

- PASS [P1] korean-status-separation: Korean standard separates completion and verification evidence.
  - evidence: Korean standard includes completion/evidence separation.
- PASS [P1] root-readme-status-separation: Root README separates ready/partial/unverified/etc.
  - evidence: Status vocabulary is present.

### S15-tool-log-and-internal-overlay-leak - 내부 로그/오버레이가 사용자 답변에 새지 않는가

- status: pass
- user risk: 사용자는 내부 상태명, 디버그 라벨, 도구 로그를 답변으로 받아 혼란과 불신을 겪는다.
- recommendation: Add fixture tests with BEAI Runtime Overlay-like input to ensure final output does not leak labels.

- PASS [P1] internal-process-stripper: Runtime has internal process line pattern filtering.
  - evidence: Internal process stripper exists.
- PASS [P1] runtime-docs-avoid-overclaim: README keeps runtime status boundary language.
  - evidence: README states no messageId, no completion claim.

### S16-session-load-and-large-context-delay - 큰 Telegram 세션에서 지연/중단을 사용자가 이해할 수 있게 다루는가

- status: pass
- user risk: 세션이 커지거나 이전 turn이 미완료이면 사용자는 두 번째 메시지가 먹통이라고 느낀다.
- recommendation: Add a synthetic large-session fixture and UX wording for delayed-but-processing state.

- PASS [P1] doctor-incomplete-turn-detects: Doctor detects incomplete turn patterns.
  - evidence: Doctor incomplete-turn detection exists.
- PASS [P1] doctor-lane-delay-detects: Doctor detects lane delay or queued processing patterns.
  - evidence: Doctor delay detection exists.

### S17-install-zip-intent-preservation - 첨부 zip 설치 의도가 memory/skill 후보로 오분류되지 않는가

- status: pass
- user risk: 사용자가 설치 파일을 보냈는데 시스템이 메모리 후보나 일반 조언으로 처리해 설치 흐름이 끊긴다.
- recommendation: Add attachment-intent fixture with zip metadata and Korean install request text.

- PASS [P1] install-candidate-session-state: Runtime tracks install attachment candidates.
  - evidence: Install candidate session maps exist.
- PASS [P1] install-guide-surface: Runtime has install guide/resume surfaces.
  - evidence: Install guide/resume surfaces exist.

## Not Performed

- no durable memory write
- no OpenClaw core change
- no Gateway or Telegram config mutation
- no cron, hook, or agent registration
- no external send
- no release packaging
- no live Telegram roundtrip

