# GPAO for OpenClaw Codex Parity Reinforcement

> Product identity: GPAO for OpenClaw.
>
> This file is part of GPAO for OpenClaw. BEAI Runtime, BEAI Capability Pack, Context Mesh, Knowledge Loop, verification tools, and release evidence are internal components of the GPAO for OpenClaw operating package.

Copyright (c) 2026 Park Jongyoon / 윤 (@aigis0927). All rights reserved.

## Purpose

This reinforcement makes GPAO for OpenClaw closer to GPAO for Codex where it matters to the user:

- self-growth does not stop at storage; it creates reviewable upgrade proposals and evidence gates.
- new-session or omitted-object turns must recover the likely target before answering.
- Context Mesh is a hard pre-answer comparison gate when must-read local evidence exists.
- package verification stays lightweight and read-only, but it checks the same product promises every time.
- Telegram/Gateway/live operations remain smooth by separating package checks from live sends, restarts, cron mutation, and durable memory promotion.

## Runtime Rules

1. Current user request always wins.
2. Previous context is comparison evidence, not a forced answer.
3. If a new session or ambiguous follow-up says "continue", "proceed", or "what test now", the runtime must name the recovered target before giving execution advice.
4. If Context Mesh returns must-read hits, the model must compare loaded evidence before direct answer.
5. If loaded evidence is absent or target matching fails, the system should ask a recovery question or report the retrieval gap instead of guessing.
6. Internal final answers, private handoffs, and reply hook candidates are not Telegram delivery proof.

## Verification

The gpao-openclaw-codex-parity gate checks:

- self-growth and upgrade loop parity
- new-session and omitted-follow-up continuity
- Context Mesh hard-gate productization
- lightweight organic OpenClaw operation

It is included in npm test and npm run verify.
