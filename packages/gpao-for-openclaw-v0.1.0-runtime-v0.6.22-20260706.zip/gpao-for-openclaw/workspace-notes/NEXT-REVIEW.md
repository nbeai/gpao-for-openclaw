# Next Review

## Next Safe Action

Closeout is ready; use the report for the final response and handoff.

## Review Before Continuing

- Check whether the current phase has pass/blocked evidence.
- Confirm that AI/developer scenario verification happened before final user review.
- Keep risky actions manual or dry-run until explicitly approved.
- Use `applied but unverified` until verification evidence exists.

## Session Resume

Closeout is ready; use the report for the final response and handoff.

## Recent Evidence

- verify: Executed 1 checks.
- closeout: Closeout decision: review.
- verify: Executed 1 checks.
- closeout: Closeout decision: ready.
- closeout: Closeout decision: ready.
