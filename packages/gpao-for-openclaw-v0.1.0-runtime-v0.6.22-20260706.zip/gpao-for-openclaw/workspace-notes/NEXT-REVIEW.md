# Next Review

## Next Safe Action

Run beai verify to inspect available checks before implementation.

## Review Before Continuing

- Check whether the current phase has pass/blocked evidence.
- Confirm that AI/developer scenario verification happened before final user review.
- Keep risky actions manual or dry-run until explicitly approved.
- Use `applied but unverified` until verification evidence exists.

## Session Resume

Implement the plan, then run beai verify.

## Recent Evidence

- closeout: Closeout decision: ready.
- closeout: Closeout decision: ready.
- preflight: Read-only workspace check completed for beai-package-for-openclaw.
- preflight: Read-only workspace check completed for beai-package-for-openclaw.
- plan: Saved build plan.
